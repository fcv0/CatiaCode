import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint


class GrowthSimulation:

    def __init__(self):
        T = 86400
        # T = 5
        dt = 1

        initial_cell_number = 10000
        initial_substrate_conc = 160000

        self.temp = 37.5
        self.Ks = 80000
        self.gr_max = 0.94 / 60 / 60

        self.Y = -0.4036

        self.t = np.arange(0, T, dt)

        combined = odeint(self.get_dy, np.array(
            [initial_cell_number, initial_substrate_conc]), self.t)

        self.cell_num = combined[:, 0]
        self.initial_substrate_conc = combined[:, 1]
        self.OD = np.zeros(self.t.shape)

    def get_dy(self, y, t):
        # using y = (cell num, substrate conce)
        dy = y.copy()
        dy[0] = (self.gr_max * (y[1])/(self.Ks + y[1]))*y[0]
        dy[1] = dy[0]/self.Y

        return dy

    def plot(self):
        plt.plot(self.t/60/60, self.cell_num, label="Cell Number")
        # plt.plot(self.t/60/60, self.OD, label="OD")
        # plt.plot(self.t, self.initial_substrate_conc, label="Substrate")
        plt.legend()
        plt.xlabel("Time(hrs)")
        plt.show()


if __name__ == "__main__":
    gs = GrowthSimulation()
    gs.plot()

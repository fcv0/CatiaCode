import numpy as np 
import os, time, serial, csv, random
from serial.tools import list_ports

class Communication:
    def __init__(self) -> None:
        self._Status = 239
        self._DeviceStatus = 239
        self._Outbound = np.zeros((60, 1), dtype=np.uint32)
        self._Inbound = np.zeros((60, 1))
        self._data2upload = None
        self._runProfileUpload = 1
        self._commsturn = True
        self._serialPort = None
        self._t = None
        self._runInProgress = False
        self._templog = np.empty((0,0), dtype=np.float32)
        self._ODlog = np.empty((0,0), dtype=np.float32)
        self._absorblog = np.empty((0,0), dtype=np.float32)
        self._scatterlog = np.empty((0,0), dtype=np.float32)
        self._commlog = np.empty((0,0),dtype=np.uint32)
        self.start_T = time.time()
        # Init commands
        self.main

    @property
    def connect_serial(self):
        def find_port():
            ports = list_ports.comports(include_links=False)
            for port in ports:
                print(f'Found port: {port.device}')
            PORT = serial.Serial(port.device)
            if PORT.isOpen():
                PORT.close()
            PORT = serial.Serial(port=port.device, baudrate=9600, timeout=.1)
            PORT.flushInput(), PORT.flushOutput()
            print(f'Connecting to {PORT.name}')
            self._serialPort = PORT.name
            return PORT

        try:
            Arduino = find_port()
            self._Status = 0
            return Arduino
        except:
            print(f'Could not find Arduino. Status: {self._Status}')
            return None
    
    def check_sum(self, data, count):
        sum1, sum2 = 0, 0
        for i in range(count):
            sum1 = (sum1 + data[i]) % 255
            sum2 = (sum1 + sum2) % 255
        checksumH, checksumL = sum2, sum1
        print(checksumH, checksumL)
        return checksumH, checksumL
    
    def int2hex(self, val):
        letters = ['A', 'B', 'C', 'D', 'E', 'F']
        leadingdigit = val // 16
        trailingdigit = val % 16

        if leadingdigit > 9:
            leadingdigit = letters[leadingdigit - 10]
        else:
            leadingdigit = str(leadingdigit)

        if trailingdigit > 9:
            trailingdigit = letters[trailingdigit - 10]
        else:
            trailingdigit = str(trailingdigit)

        hex_val = leadingdigit + trailingdigit
        return hex_val
    
    def hex2int(self, val):
        return int(val, 16)

    def bytes2long32(self, byte1, byte2, byte3, byte4):
        tmp_val_1 = sum(int(bit) << (8 - x) for x, bit in enumerate(bin(byte4)[2:].zfill(8)))
        tmp_val_2 = sum(int(bit) << (16 - x) for x, bit in enumerate(bin(byte3)[2:].zfill(8), 9))
        tmp_val_3 = sum(int(bit) << (24 - x) for x, bit in enumerate(bin(byte2)[2:].zfill(8), 17))
        tmp_val_4 = sum(int(bit) << (32 - x) for x, bit in enumerate(bin(byte1)[2:].zfill(8), 25))
        val = tmp_val_1 + tmp_val_2 + tmp_val_3 + tmp_val_4
        return val

    def bytes2float32(self, byte1, byte2, byte3, byte4):
        #return tmp
        pass

    def long322bytes(self, val):
        # b1, b2, b3, b4
        pass
    
    def int162bytes(self, val):
        #return b1, b2
        pass

    def randbyte(self):
        val = random.randint(0, 255)
        return val

    @property
    def runSequ323334(self):
        data = self._data2upload    
        self._Outbound[5] = data[0]
        timeTrig = round(int(data[1])*60)
        timeTrig = np.uint32(timeTrig)
        self._Outbound[6], self._Outbound[7], self._Outbound[8], self._Outbound[9] = self.long322bytes(timeTrig)
        tempTrig = np.uint16(int(data[2])*10)
        self._Outbound[10], self._Outbound[11] = self.int162bytes(tempTrig)

        # ADD OD TRIG ETC.. ODSENS ODTARG ETC...

        if self._Status == 32:
            self._Outbound[30], self._Outbound[31] = self.int162bytes(self._data2upload)
            self._Status = 34
            if self._runProfileUpload == len(self._data2upload) - 1:
                self._Status = 33
            elif self._Status == 33:
                self._Status = 0
            elif self._Status == 34:
                self._Status = 34
                if self._runProfileUpload == len(self._data2upload) - 1:
                    self._Status = 33
        self._runProfileUpload = self._runProfileUpload + 1

    @property
    def encodeOut(self):
        self._Outbound[0] = self._Status
        currentTime = round(time.time() - self.start_T)# IDK WHAT MATLAB IS SAYING TO ME ;( 
        currentTime = np.uint32(currentTime)
        #self._Outbound[1], self._Outbound[2], self._Outbound[3], self._Outbound[4] = self.long322bytes(currentTime)
        if self._Status == 32 or 33 or 34:
            self.runSequ323334 # Start run sequence
        elif self._Status == 2:
            self._templog = np.empty((0,0), dtype=np.float32)
            self._ODlog =  np.empty((0,0), dtype=np.float32)
            self._scatterlog =  np.empty((0,0), dtype=np.float32)
            self._absorblog =  np.empty((0,0), dtype=np.float32)
            self._Status = 0
        elif self._Status == 48: # Temperature caliberation
            self._Outbound[5], self._Outbound[6], self._Outbound[7], self._Outbound[8] = self.long322bytes(np.uint32()) # calibrate gradient field
            self._Outbound[9], self._Outbound[10], self._Outbound[11], self._Outbound[12] = self.long322bytes(np.uint32()) # calibrate constant off set field
            self._Status = 0
        elif self._Status == 50: # PID for temperature
            self._Outbound[5], self._Outbound[6], self._Outbound[7], self._Outbound[8] = self.long322bytes(np.uint32()) # P field
            self._Outbound[9], self._Outbound[10], self._Outbound[11], self._Outbound[12] = self.long322bytes(np.uint32()) # I field
            self._Outbound[13], self._Outbound[14], self._Outbound[15], self._Outbound[16] = self.long322bytes(np.uint32()) # D field
            self._Status = 0
        elif self._Status == 64: # OD calibration
            self._Outbound[5], self._Outbound[6], self._Outbound[7], self._Outbound[8] = self.long322bytes(np.uint32()) # Calibrate gradient field
            self._Outbound[9], self._Outbound[10], self._Outbound[11], self._Outbound[12] = self.long322bytes(np.uint32()) # Calibrate constant offset field
            self._Outbound[13], self._Outbound[14], self._Outbound[15], self._Outbound[16] = self.long322bytes(np.uint32()) # Ref absorbance field
            self._Status = 0
        elif self._Status == 66: # PID for OD
            self._Outbound[5], self._Outbound[6], self._Outbound[7], self._Outbound[8] = self.long322bytes(np.uint32()) # P value field
            self._Outbound[9], self._Outbound[10], self._Outbound[11], self._Outbound[12] = self.long322bytes(np.uint32()) # I value field
            self._Outbound[13], self._Outbound[14], self._Outbound[15], self._Outbound[16] = self.long322bytes(np.uint32()) # D value field
            self._Status = 0
        else:
            self._Status = 0
        
        self._Outbound[58], self._Outbound[59] = self.check_sum(self._Outbound, 57)


    @property
    def decodeIn(self):
        '''
        Might need to reorganise some of the hstacking methods, might only need a single per the entire function to make it more simplistic.
        '''
        self._DeviceStatus = self._Inbound[0]
        WRTOD, WRTT = 'w', 'w'
        if self._DeviceStatus == 0 or self._DeviceStatus == 1:
            OD_HEADER = ['OD', 'Absorb', 'Scatter']
            ODdata = np.hstack((self._ODlog.reshape(-1, 1), self._absorblog.reshape(-1, 1), self._scatterlog.reshape(-1, 1)))
            TEMPdata = self._templog.reshape(-1, 1)
            if os.path.isfile('tmp_OD.csv') == False:
                WRTOD = 'x'
            with open('tmp_OD.csv', mode=WRTOD, newline='') as log:
                write = csv.writer(log)
                write.writerow(OD_HEADER)
                write.writerows(ODdata)
            if os.path.isfile('tmp_TEMP.csv') == False:
                WRTT = 'x'
            with open('tmp_TEMP.csv', mode=WRTT, newline='') as log:
                write = csv.writer(log)
                write.writerow(['Temperature'])
                write.writerows(TEMPdata)

        elif self._DeviceStatus == 3:
            self._runInProgress = False
            WRTODF, WRTTF = 'w', 'w'
            ODdata = np.hstack((self._ODlog.reshape(-1, 1), self._absorblog.reshape(-1, 1), self._scatterlog.reshape(-1, 1)))
            if os.path.isfile('final_OD.csv') == False:
                WRTODF = 'x'
            with open('FINAL_OD.csv', mode=WRTODF, newline='') as log:
                write = csv.writer(log)
                write.writerow(OD_HEADER)
                write.writerows(ODdata)
            if os.path.isfile('FINAL_TEMP.csv') == False:
                WRTTF = 'x'
            with open('FINAL_TEMP.csv', mode=WRTTF, newline='') as log:
                write = csv.writer(log)
                write.writerow(['Temperature'])
                write.writerows(TEMPdata)

        elif self._DeviceStatus == 4:
            self._Inbound[6], self._Inbound[7], self._Inbound[8], self._Inbound[9] = 2, 4, 6, 2
            OD_time = self.bytes2long32(self._Inbound[5], self._Inbound[6], self._Inbound[7], self._Inbound[8])
            print(OD_time)
            absorb1 = self.bytes2float32(self._Inbound[9], self._Inbound[10], self._Inbound[11], self._Inbound[12])
            # etc 

            scatter1 = self.bytes2float32(self._Inbound[33], self._Inbound[34], self._Inbound[35], self._Inbound[36])
            #etc

        elif self._DeviceStatus == 5:
            self._Inbound[6], self._Inbound[7], self._Inbound[8], self._Inbound[9] = 2, 4, 6, 2
            OD_time = self.bytes2long32(self._Inbound[5], self._Inbound[6], self._Inbound[7], self._Inbound[8])
            print(OD_time)
            absorb1 = self.bytes2float32(self._Inbound[9], self._Inbound[10], self._Inbound[11], self._Inbound[12])
            # etc 

            scatter1 = self.bytes2float32(self._Inbound[33], self._Inbound[34], self._Inbound[35], self._Inbound[36])
        elif self._DeviceStatus == 6:
            TEMP_time = self.bytes2long32(self._Inbound[5], self._Inbound[6], self._Inbound[7], self._Inbound[8])
            TEMP = self.bytes2float32(self._Inbound[9], self._Inbound[10], self._Inbound[11], self._Inbound[12])
            tmptemplog = [TEMP_time, TEMP]
            if len(self._templog) == 0:
                self._templog == tmptemplog
            else:
                self._templog += tmptemplog
    
    @property
    def main(self):
        WRTC = 'w'
        if self._DeviceStatus == 239:
            ARDUINO = self.connect_serial
        if self._commsturn:
            self.encodeOut
            outSTR = ''
            for i in range(60):
                outSTR += self.int2hex(self._Outbound[i][0]) + '/'
            ARDUINO.write(np.uint8(self._Outbound))
            if len(self._commlog) == 0:
                self._commlog = np.transpose(self._Outbound)
            else:
                self._commlog += np.transpose(self._Outbound)
            self._commsturn = False
            if os.path.isfile('commslog.csv') == False:
                WRTC = 'x'
            with open('commslog.csv', mode=WRTC, newline='') as log:
                write = csv.writer(log)
                write.writerows(self._commlog)
        else:
            if ARDUINO._bytesize >= 59:
                self._Inbound = serial.Serial.read(ARDUINO, 60)
            if len(self._commlog) == 0:
                self._commlog = np.transpose(self._Inbound)
            else:
                self._commlog += np.transpose(self._Inbound)
            self.decodeIn
            inboundSTR = '' 
            for i in range(60):
                inboundSTR += self.int2hex(self._Inbound[i][0])
            self._commsturn = True
        

if __name__ == '__main__':
    os.chdir(os.path.abspath(os.path.dirname(__file__)))
    com = Communication()
import serial, time, os, csv, numpy, struct
import matplotlib.pyplot as plt
from serial.tools import list_ports

C3 = []

def find_port():
    ports = list_ports.comports(include_links=False)
    for port in ports:
        print(f'Found port: {port.device}')
    PORT = serial.Serial(port.device)
    print('Device information: ', PORT)
    if PORT.isOpen():
        PORT.close()
    PORT = serial.Serial(port=port.device, baudrate=9600, timeout=1)
    PORT.flushInput(), PORT.flushOutput()
    print(f'Connecting to {PORT.name}')
    return PORT

def send_cali_msg(info):
    '''
    Gonna fix this, next for sending a status array, then back
    '''
    Arduino.write(bytes(info.encode()))

def byte_decoder():
    '''
    IDK what it fuck it can handle, i just did one value at a time... 
    '''
    data = Arduino.readlines()
    byte_amount = len(data)
    print('Bytes: ', byte_amount)
    print('Data: ', data)

    if byte_amount != 0:
        if byte_amount == 1:
            data = data[0]

    def bytes2float(d):
        assert len(d) == 4
        return struct.unpack('<f', d)[0]

    def bytes2int(d):
        try:
            assert len(d) == 1 or len(d) == 0
            val = int.from_bytes(d, byteorder='little')
            return val
        except:
            return None

    if Arduino.inWaiting() == 4:
        decoded = bytes2float(data)
        print(decoded, 'decoded data')

    if Arduino.inWaiting() == 0:
        decoded = bytes2int(data)
        print(decoded)


if __name__ == '__main__':
    try:
        Arduino = find_port()
    except:
        print('Arduino not found...')
    while True:
        send_cali_msg("OD3")
        byte_decoder()
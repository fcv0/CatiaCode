#include <Arduino.h>

#define totalLEDs 6
#define totalLEDsMedia 6
#define totalPumps 9

#define pumpOverideSpeed 177
#define ODSensorDelay 1600
#define tempSensorDelay 20


//fossil record
#define X false
#define Y true

#define overstepSteps 1000

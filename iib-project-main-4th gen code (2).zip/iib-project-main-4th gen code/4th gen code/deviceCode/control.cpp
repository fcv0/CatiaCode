#include "control.h"

//generic PID controller
PIDController::PIDController(int targ, int p, int i, int d) {
  setCoeffs(p, i, d);
  setTarget(targ);
  prevError = 0;
}

PIDController::PIDController() {
  setCoeffs(0, 0, 0);
  setTarget(0);
  prevError = 0;
  prevMillis = millis();
}

//output scales from 0-255 rather than 0-1
float PIDController::updateOutput(float newVal) {
  float elapsedTime = (millis() - prevMillis) / 1000;

  error = target - newVal;
  runningIntegral += ((error + prevError) / 2) * elapsedTime;
  a = (kp * error + ki * runningIntegral + kd * ((error - prevError) / elapsedTime));

  prevError = error;
  prevMillis = millis();
  return a;
}

void PIDController::setCoeffs(float p, float i, float d) {
  kp = p;
  ki = i;
  kd = d;
}

void PIDController::resetIntegral() {
  runningIntegral = 0;
}

void PIDController::setTarget(float targ) {
  target = targ;
}

void PIDController::applyClipping(float overSat) {
  // prevents the integral becoming oversaturated
  runningIntegral += -overSat / ki;
}


//Temperature controller
TempController::TempController(float targ, int outputPin_) {
  reversed = false;
  outputPin = outputPin_;
  target = targ;
  controlMode = 1;
  pid = PIDController(targ, 0, 0, 0);
  cycleStartTime = millis();
  heaterPower = 0;
  heaterPowerSet = 0;
}

//temperature controller where the active component is a cooler rather than a heater if reversed_ is true
TempController::TempController(float targ, int outputPin_, bool reversed_) {
  reversed = reversed_;
  target = targ;
  controlMode = 1;
  pid = PIDController(targ, 0, 0, 0);
  cycleStartTime = millis();
  heaterPower = 0;
  heaterPowerSet = 0;
}

void TempController::updateOutput(float newVal) {
  if (controlMode == 1) {            //on off
    if (newVal < target) {
      heaterPower =  255;
    } else {
      heaterPower =  0;
    }
  } else if (controlMode == 2) {      //hysteressis
    if (newVal < lowerHystVal) {
      heaterPower = 255;
    } else if (newVal > upperHystVal) {
      heaterPower = 0;
    }
  } else if (controlMode == 3) {      //pid
    float pidOut =  pid.updateOutput(newVal);
    heaterPower = (int) min(255, max(0, pidOut));
    float overSaturation = 0;
    if (pidOut > 255.0) {
      overSaturation = pidOut - 255.0;
    } else if (pidOut < 0) {
      overSaturation = pidOut;
    }
    pid.applyClipping(overSaturation);
  } else {
    heaterPower = 0;
  }
  if (reversed) {
    heaterPower = 255 - heaterPower;
  }
  setHeaterPower();
}
void TempController::setTarget(float targ) {
  target = targ;
  if (controlMode == 3) {
    pid.setTarget(target);
  }
}
void TempController::setModePID(float p, float i, float d) {
  if (controlMode == 3) {
    pid.setCoeffs(p, i, d);
  } else {
    controlMode = 3;
    pid = PIDController(target, p, i, d);
  }
}

void TempController::setModeHyst(float lb, float ub) {
  if (controlMode == 2) {
    lowerHystVal = lb;
    upperHystVal = ub;
  } else {
    controlMode = 2;
    lowerHystVal = lb;
    upperHystVal = ub;
  }
}

void TempController::setModeOnOff() {
  controlMode = 1;
}

void TempController::setHeaterPower() {
  // uses a duty cycle system
  if (heaterPower > 255) {
    heaterPower = 255;
  } else if (heaterPower < 0) {
    heaterPower = 0;
  }
  unsigned long curTime = millis();
  unsigned long cycleTime = curTime - cycleStartTime;
  if (cycleTime > heaterDutyCycle * 1000) {
    cycleStartTime += heaterDutyCycle * 1000;
    cycleTime = curTime - cycleStartTime;
  }
  unsigned long triggerTime = ((unsigned long)heaterDutyCycle * 1000 * (unsigned long)heaterPower);
  if (255 * cycleTime < triggerTime) {
    digitalWrite(outputPin, HIGH);
    heaterPowerSet = 255;
  } else {
    digitalWrite(outputPin, LOW);
    heaterPowerSet = 0;
  }
}

//OD control
ODController::ODController(float targ) {
  target = targ;
  controlMode = 1;
  pid = PIDController(targ, 0, 0, 0);
  pumpPower = 0;
}

void ODController::updateOutput(float newVal) {   ///target is an OD
  if (controlMode == 1) {            //on off
    if (newVal < target) {
      pumpPower =  0;
    } else {
      pumpPower =  255;
    }
  } else if (controlMode == 2) {      //hysteressis
    if (newVal < lowerHystVal) {
      pumpPower = 0;
    } else if (newVal < upperHystVal) {
      pumpPower = pumpPower;
    } else if (newVal > upperHystVal) {
      pumpPower = 255;
    }
  } else if (controlMode == 4) {      //pid
    float pidOut =  pid.updateOutput(newVal);
    pumpPower = (int) min(255, max(0, pidOut));
  } else {
    pumpPower = 0;
  }
  setPumps();
}
void ODController::setTarget(float targ) {
  target = targ;
  if (controlMode == 4) {
    pid.setTarget(target);
  }
  if (controlMode == 2) {
    controlMode = 1;
  }
}

void ODController::setTarget(float targ, float drift) {
  target = targ;
  if (drift == 0) {
    controlMode = 1;
  } else {
    controlMode = 2;
    upperHystVal = target + abs(drift);
    lowerHystVal = target - abs(drift);
  }
}

void ODController::setModePID(float p, float i, float d) {
  if (controlMode == 4) {
    pid.setCoeffs(p, i, d);
  } else {
    controlMode = 4;
    pid = PIDController(target, p, i, d);
  }
}

void ODController::setModeHyst(float lb, float ub) {
  if (controlMode == 2) {
    lowerHystVal = lb;
    upperHystVal = ub;
  } else {
    controlMode = 2;
    lowerHystVal = lb;
    upperHystVal = ub;
  }
}

void ODController::setModeOnOff() {
  controlMode = 1;
}

void ODController::setModeConstFlow(int power) {
  controlMode = 0;
  pumpPower = power;
}

void ODController::setPumps() {
  if (pumpPower > 255) {
    pumpPower = 255;
  } else if (pumpPower < 0) {
    pumpPower = 0;
  }
}

PumpController::PumpController() {

}

void PumpController::applySpeedToPump(int pumpNum) {

  if (reversible[pumpNum]) {
    boolean reversed = pumpSpeeds[pumpNum] < 0;
    boolean enabled = !(abs(pumpSpeeds[pumpNum]) == 0);

    if (twoPinReverse[pumpNum]) {
      digitalWrite(dirPins[pumpNum], reversed);
      digitalWrite(onOffPins[pumpNum], !reversed);
    } else {
      digitalWrite(dirPins[pumpNum], reversed);
      digitalWrite(onOffPins[pumpNum], enabled);
    }
  }

  analogWrite(speedPins[pumpNum], abs(pumpSpeeds[pumpNum]));  
}

void PumpController::setPumpSpeed(int pumpNum, int pumpSpeed, boolean overide) {
  if (pumpNum < 0 || pumpNum > totalPumps || pumpSpeed > 255 || pumpSpeed < -255) {
    return;
  }

  if ((overide && pumpSpeeds[pumpNum] != pumpSpeed) || (!pumpOverides[pumpNum] && (pumpSpeeds[pumpNum] != pumpSpeed))) {
    speedsChanged = true;
    pumpUpdateTime = millis();
  }

  if (pumpOverides[pumpNum] && !overide) {
    // if the pump is currently overidden and command isn't an override store speed for when overide is disabled
    nonOverideSpeeds[pumpNum] = pumpSpeed;
  } else if (!pumpOverides[pumpNum] && overide) {
    // if pump not already overridden but new command is overide
    nonOverideSpeeds[pumpNum] = pumpSpeeds[pumpNum];
    pumpSpeeds[pumpNum] = pumpSpeed;
  } else {
    // if pump not overridden and new command is not overide or pump is overriden and new comman is override
    pumpSpeeds[pumpNum] = pumpSpeed;
  }

  if (overide) {
    pumpOverides[pumpNum] = overide;
  } else {
    nonOverideSpeeds[pumpNum] = pumpSpeed;
  }

  if (speedsChanged) {
    applySpeedToPump(pumpNum);
  }


}



void PumpController::releasePumpOverides(int pumpNum, boolean overide) {
  if (pumpNum < 0 || pumpNum > totalPumps) {
    return;
  }
  if (!overide) {
    // turn off overide
    pumpOverides[pumpNum] = false;

    // reapply the non overide speed to the pump
    pumpSpeeds[pumpNum] = nonOverideSpeeds[pumpNum];
    speedsChanged = true;
  }
  applySpeedToPump(pumpNum);
}

void PumpController::dilute(int power) {
  // scale the power of the dilution to that given
  float workingValue = float(power) * float(maxDilutionPower) / 255.0;
  dilutionPower = (byte) round(workingValue);

  // reset dilution status variables
  dilutionFlag = true;
  dilutionStage = 0;
}

void PumpController::drainSensors() {
  //set pump speeds
  setPumpSpeed(0, -255, false);
  setPumpSpeed(3, -255, false);
  speedsChanged = true;

  // add timer to pumps
  pumpOffTime[0] = millis() + 5000;
  pumpOffTime[3] = millis() + 5000;
}

void PumpController::fillSensors() {
  //set pump speeds
  setPumpSpeed(0, 255, false);
  setPumpSpeed(3, 255, false);
  speedsChanged = true;

  // add timer to pumps
  pumpOffTime[0] = millis() + 5000;
  pumpOffTime[3] = millis() + 5000;
}

void PumpController::cycleSensors() {
  //trigger drain
  drainSensors();

  // wait for pumps to finish draining
  while (pumpOffTime[0] != 0 || pumpOffTime[3] != 0) {
    updatePumps();
  }

  //trigger cuvette filling
  fillSensors();

  // wait for pumps to finish filling
  while (pumpOffTime[0] != 0 || pumpOffTime[3] != 0) {
    updatePumps();
  }
}

void PumpController::updatePumps() {
  //repeatedly called to asynchronously manage pumps

  latest_time = millis();

  //dilution management
  if (dilutionFlag) {
    if (dilutionStage == 0) {
      //remove waste
      dilutionStartTime = latest_time;
      setPumpSpeed(4, dilutionPower, false);
      speedsChanged = true;
      dilutionStage = 1;
    }
    else if (dilutionStage == 1 && latest_time - dilutionStartTime > dilutionTime) {
      // wait for waste to finish being removed then start adding fresh media
      float timePassed = latest_time - dilutionStartTime;
      mainChamberVolumeBalance -= pumpMaxFlowRate[2] * ((timePassed)/1000+pumpTimeConstant[2] * exp(-(timePassed)/(1000*pumpTimeConstant[2])));
      setPumpSpeed(4, 0, false);
      dilutionStage = 2;
      dilutionStartTime = latest_time;
      setPumpSpeed(2, dilutionPower, false);
      if (mediaPrepSetup == 2) {
        setPumpSpeed(1, dilutionPower, false);
      }
      speedsChanged = true;
    } else if(dilutionStage == 2 && mediaPrepSetup != 2){
      // turn off media transfer pump when main chamber volume is replaced
      float timePassed = latest_time - dilutionStartTime;
      float pump2VolMoved = pumpMaxFlowRate[1] * ((timePassed)/1000+pumpTimeConstant[1] * exp(-(timePassed)/(1000*pumpTimeConstant[1])));
      if(0 < mainChamberVolumeBalance + pump2VolMoved){
        mainChamberVolumeBalance += pump2VolMoved;
        mediaChamberVolumeBalance -= pump2VolMoved;
        setPumpSpeed(2, 0, false); 
        dilutionStage = 0;
        dilutionFlag = false;
      }      
    }else if(dilutionStage == 2 && mediaPrepSetup == 2){
     // handel disabling of media transfer and media in pumps
     float timePassed = latest_time - dilutionStartTime;
     float pump2VolMoved = pumpMaxFlowRate[1] * ((timePassed)/1000+pumpTimeConstant[1] * exp(-(timePassed)/(1000*pumpTimeConstant[1])));
     float pump1VolMoved = pumpMaxFlowRate[0] * ((timePassed)/1000+pumpTimeConstant[0] * exp(-(timePassed)/(1000*pumpTimeConstant[0])));
     if(0 < mainChamberVolumeBalance + pump2VolMoved){
        // turn off media transfer pump when balanced (leave media in running)
        mainChamberVolumeBalance += pump2VolMoved;
        mediaChamberVolumeBalance -= pump2VolMoved;
        setPumpSpeed(2, 0, false);
        dilutionStage = 3; 
      }
      else if(0 < mainChamberVolumeBalance + pump1VolMoved + mediaChamberVolumeBalance){
        // turn off media in pump when balance expected (leave media trans running)
        mediaChamberVolumeBalance += pump1VolMoved;
        setPumpSpeed(1, 0, false);
        dilutionStage = 4;
      }
    }else if(dilutionStage == 3){
      // turn off media in pump once balanced
      float timePassed = latest_time - dilutionStartTime;
      float pump1VolMoved = pumpMaxFlowRate[0] * ((timePassed)+pumpTimeConstant[0] * exp(-timePassed/(1000*pumpTimeConstant[0])));
      if(0 < mediaChamberVolumeBalance + pump1VolMoved){
        mediaChamberVolumeBalance += pump1VolMoved;
        setPumpSpeed(1, 0, false);
        dilutionStage = 0;
        dilutionFlag = false; 
      }
    }else if(dilutionStage == 4){
      // turn off media trans pump once balanced
      float timePassed = latest_time - dilutionStartTime;
      float pump2VolMoved = pumpMaxFlowRate[1] * ((timePassed)/1000+pumpTimeConstant[1] * exp(-timePassed/(1000*pumpTimeConstant[1])));
      if(0 < mainChamberVolumeBalance + pump2VolMoved){
        mainChamberVolumeBalance += pump2VolMoved;
        setPumpSpeed(2, 0, false);
        dilutionStage = 0;
        dilutionFlag = false; 
      }
    }
  }
  //constant dilution mode
  else if (fixedDilutionRateEnabled) {
    if ((latest_time - dilutionStartTime + dilutionTime) > fixedDilutionRate) {
      dilute(255);
    }
  }

  //pump timer system, turns pumps off after a certain time
  for (int i = 0; i < totalPumps; i++) {
    if (latest_time > pumpOffTime[i] && pumpOffTime[i] > 0) {
      setPumpSpeed(i, 0, false);
      pumpOffTime[i] = 0;
    }
  }
}

//void PumpController::updatePumps() {
//  //repeatedly called to asynchronously manage pumps
//
//  latest_time = millis();
//
//  //dilution management
//  if (dilutionFlag) {
//    if (dilutionStage == 0) {
//      //remove waste
//      dilutionStartTime = latest_time;
//      setPumpSpeed(4, dilutionPower, false);
//      speedsChanged = true;
//      //if pumps are out of balance with each other by more than a certain threshold re-equal the volume removed and added
//      if (accrewedDilutionVolume[0] - accrewedDilutionVolume[2] > volumeOffsetThreshold || accrewedDilutionVolume[1] - accrewedDilutionVolume[2] > volumeOffsetThreshold) {
//        dilutionStage = 5;
//        excessTimeNeeded = 60000 * (max(accrewedDilutionVolume[0] - accrewedDilutionVolume[2], accrewedDilutionVolume[1] - accrewedDilutionVolume[2])) / pumpFullFlowRate[2];
//      } else {
//        dilutionStage = 1;
//      }
//    }
//    else if (dilutionStage == 1 && latest_time - dilutionStartTime > dilutionTime) {
//      // wait for waste to finish being removed then start adding fresh media
//      accrewedDilutionVolume[2] += pump2sFlowRate[2] * 2.0 / 60.0 + (latest_time - dilutionStartTime - 2000) * pumpFullFlowRate[2] / 60000.0;
//      setPumpSpeed(4, 0, false);
//      dilutionStage = 2;
//      dilutionStartTime = latest_time;
//      setPumpSpeed(2, dilutionPower, false);
//      if (mediaPrepSetup == 2) {
//        setPumpSpeed(1, dilutionPower, false);
//      }
//      speedsChanged = true;
//    } else if (dilutionStage == 5 && latest_time - dilutionStartTime > dilutionTime + excessTimeNeeded) {
//      // wait for waste to finish being removed then start adding fresh media but wait longer to balance pumps
//      accrewedDilutionVolume[2] += pump2sFlowRate[2] * 2.0 / 60.0 + (latest_time - dilutionStartTime - 2000) * pumpFullFlowRate[2] / 60000.0;
//      setPumpSpeed(4, 0, false);
//      dilutionStage = 2;
//      dilutionStartTime = latest_time;
//      setPumpSpeed(2, dilutionPower, false);
//      if (mediaPrepSetup == 2) {
//        setPumpSpeed(1, dilutionPower, false);
//      }
//      speedsChanged = true;
//    }
//    else if (dilutionStage == 2 && (latest_time - dilutionStartTime) > (dilutionTime)) {
//      // wait to stop adding media and turn off pumps
//      accrewedDilutionVolume[0] += pump2sFlowRate[0] * 2.0 / 60.0 + (latest_time - dilutionStartTime - 2000) * pumpFullFlowRate[0] / 60000.0;
//      accrewedDilutionVolume[1] += pump2sFlowRate[1] * 2.0 / 60.0 + (latest_time - dilutionStartTime - 2000) * pumpFullFlowRate[1] / 60000.0;
//      dilutionEndTime = latest_time;
//      if ((accrewedDilutionVolume[2] - accrewedDilutionVolume[0]) > volumeOffsetThreshold) {
//        setPumpSpeed(2, 0, false);
//        speedsChanged = true;
//        dilutionStage = 3;
//        excessTimeNeeded = 60000 * (accrewedDilutionVolume[2] - accrewedDilutionVolume[0]) / pumpFullFlowRate[0];
//      } else if (accrewedDilutionVolume[2] - accrewedDilutionVolume[1] > volumeOffsetThreshold) {
//        setPumpSpeed(1, 0, false);
//        speedsChanged = true;
//        dilutionStage = 4;
//        excessTimeNeeded = 60000 * (accrewedDilutionVolume[2] - accrewedDilutionVolume[1]) / pumpFullFlowRate[1];
//      } else {
//        dilutionFlag = false;
//        dilutionStage = 0;
//        setPumpSpeed(2, 0, false);
//        setPumpSpeed(1, 0, false);
//        speedsChanged = true;
//      }
//    } else if (dilutionStage == 3 && (latest_time - dilutionEndTime) > excessTimeNeeded) {
//      // if one media pump left on (media to main chamber)
//      accrewedDilutionVolume[0] += (latest_time - dilutionEndTime) * pumpFullFlowRate[0] / 60000.0;
//      setPumpSpeed(1, 0, false);
//      speedsChanged = true;
//      dilutionFlag = false;
//      dilutionStage = 0;
//    } else if (dilutionStage == 4 && (latest_time - dilutionEndTime) > excessTimeNeeded) {
//      // if one media pump left on (fresh media to media prep)
//      setPumpSpeed(2, 0, false);
//      speedsChanged = true;
//      accrewedDilutionVolume[1] += (latest_time - dilutionEndTime) * pumpFullFlowRate[1] / 60000.0;
//      dilutionFlag = false;
//      dilutionStage = 0;
//    }
//
//  }
//  //constant dilution mode
//  else if (fixedDilutionRateEnabled) {
//    if ((latest_time - dilutionStartTime + dilutionTime) > fixedDilutionRate) {
//      dilute(255);
//    }
//  }
//
//  //pump timer system, turns pumps off after a certain time
//  for (int i = 0; i < totalPumps; i++) {
//    if (latest_time > pumpOffTime[i] && pumpOffTime[i] > 0) {
//      setPumpSpeed(i, 0, false);
//      pumpOffTime[i] = 0;
//    }
//  }
//}

void PumpController::setPinchValves(int valveStates){
  for(int i = 0; i < 8; i++){
    if(bitRead(valveStates, i) == 1){
        digitalWrite(pinchPins[i], HIGH);
    }else{
      digitalWrite(pinchPins[i], LOW);
    }
  }
}

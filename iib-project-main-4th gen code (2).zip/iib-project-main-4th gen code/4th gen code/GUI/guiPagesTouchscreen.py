from GUI.guiWidgets import *

import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from functools import partial
import os

# import schemdraw
# import schemdraw.elements as elm

import matplotlib.pyplot as plt
import numpy as np
import time


class SubpageScafoldTouchscreen(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.grid_columnconfigure(0, weight=1, minsize = 200)
        self.grid_columnconfigure(1, weight=1, minsize = 200)
        self.grid_columnconfigure(2, weight=1, minsize = 200)
        self.grid_columnconfigure(3, weight=1, minsize = 200)
        self.grid_columnconfigure(4, weight=1, minsize = 200)

        self.grid_rowconfigure(0, weight=1, minsize = 100)
        self.grid_rowconfigure(1, weight=1, minsize = 100)
        self.grid_rowconfigure(2, weight=1, minsize = 100)
        self.grid_rowconfigure(3, weight=1, minsize = 100)
        self.grid_rowconfigure(4, weight=1, minsize = 100)
        self.grid_rowconfigure(5, weight=1, minsize = 100)

        homeIcon = tk.PhotoImage(file = r"C:\Users\jim-b\Documents\University\IIB\Project\Programs\4th gen code\GUI\images\homeIcon.png")

        homeButton = ButtonStackWidget(
            self, controller, ("Home", "Home", lambda x: controller.show_frame("Navscreen1")), images = [homeIcon])
        homeButton.grid(row=4, column=4,rowspan = 2, sticky="NSEW")


class NavPage1Touchscreen(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.grid_columnconfigure(0, weight=1)

        self.grid_rowconfigure(0, weight=1)

        frameKeys = ["ExperimentStp", "ExperimentPrep",
                     "Overides", "Control", "Fossilrecord", "Settings"]

        rt = os.path.abspath(os.path.dirname(__file__))

        images = [tk.PhotoImage(file = rt + r"\images\startIcon.png").subsample(8),
                  tk.PhotoImage(file = rt + r"\images\bacteriaIcon.png").subsample(8),
                  tk.PhotoImage(file = rt + r"\images\overideIcon.png").subsample(8),
                  tk.PhotoImage(file = rt + r"\images\controlIcon.png").subsample(8),
                  tk.PhotoImage(file = rt + r"\images\fossilIcon.png").subsample(8),
                  tk.PhotoImage(file = rt + r"\images\settingsIcon.png").subsample(18)]
        navButtons = ButtonStackWidget(
            self, controller, *[(k, k, partial(controller.show_frame, k)) for k in frameKeys], images = images,
            columns=3, argumentlessCallback = True)
        navButtons.grid(row=0, column=0, sticky="NSEW")


class ExperimentStpTouchscreen(SubpageScafoldTouchscreen):
    def __init__(self, parent, controller):
        self.controller = controller
        SubpageScafoldTouchscreen.__init__(self, parent, controller)

        runSettings = dataInputStackWidget(self, controller,
                                            ("Temperature ($\deg$ C)", lambda x: controller.comm_handler.set_temp_target(x, transmit = True)),
                                            ("Temperature Sensing Interval (ms)", lambda x: controller.comm_handler.set_temp_sensing_interval(x, transmit = True)),
                                            ("OD Sensing Interval (ms)", lambda x: controller.comm_handler.set_OD_sensing_interval(x, transmit = True)),
                                            ("OD Sensor Circulation Rate (0-255)", lambda x: controller.comm_handler.set_circulation_speed(x)),
                                            ("Culture Mixing Speed (0-255)",  lambda x: controller.comm_handler.set_mixing_speed(x)))
        runSettings.grid(row = 0, column = 0, rowspan = 4, columnspan = 3, sticky = "NSEW")

        load_btns = ButtonStackWidget(self, controller,
                                      ("load preset", "load preset", lambda x: 2),
                                      ("load sequence", "load sequence", lambda x: 2),
                                      ("Start Run","Start Run", lambda x: controller.comm_handler.set_Status(
                                         2)))
        load_btns.grid(row=0, column=4, rowspan = 4, sticky="NSEW")


    def update_data_every(self):
        if self.controller.comm_handler.run_in_progress and self.controller.currentFrame == "ExperimentStp":
            self.controller.show_frame("ExperimentRun")


class ExperimentRunTouchscreen(SubpageScafoldTouchscreen):
    def __init__(self, parent, controller):
        SubpageScafoldTouchscreen.__init__(self, parent, controller)
        
        self.controller = controller

        communicationsDataView = DataDisplayWidget(self, controller, ("PC Status", lambda: controller.comm_handler._Status),
                                                   ("Device Status", lambda: controller.comm_handler._DeviceStatus), columns=2)
        communicationsDataView.grid(row=0, column=0, columnspan = 4, sticky="NSEW")

        self.curGraph = 0
        self.lastGraphChange = time.time()

        self.tempDataView = PlotDataDisplayWidget(self, controller,
                                             ("Temperature IR",
                                              lambda: controller.comm_handler._TempIR[-1] if len(
                                                  controller.comm_handler._TempIR) > 0 else "nan",
                                              lambda x: controller.comm_handler.set_plot_bools("Temp", 0, bool(x))),
                                             ("Temperature Immersed",
                                              lambda: controller.comm_handler._Temp[-1] if len(
                                                  controller.comm_handler._Temp) > 0 else "nan",
                                              lambda x: controller.comm_handler.set_plot_bools("Temp", 1, bool(x))),
                                             ("Media Temperature IR",
                                              lambda: controller.comm_handler._TempIR_media[-1] if len(
                                                  controller.comm_handler._TempIR_media) > 0 else "nan",
                                              lambda x: controller.comm_handler.set_plot_bools("Temp Media", 0, bool(x))),
                                             ("Media Temperature Immersed",
                                              lambda: controller.comm_handler._Temp_media[-1] if len(
                                                  controller.comm_handler._Temp_media) > 0 else "nan",
                                              lambda x: controller.comm_handler.set_plot_bools("Temp Media", 1, bool(x))),
                                              columns = 2)
        
        self.ODDataView = PlotDataDisplayWidget(self, controller,
                                           ("OD1",
                                            lambda: controller.comm_handler._OD[0, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 0, bool(x))),
                                           ("OD2",
                                            lambda: controller.comm_handler._OD[1, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 1, bool(x))),
                                           ("OD3",
                                            lambda: controller.comm_handler._OD[2, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 2, bool(x))),
                                           ("OD4",
                                            lambda: controller.comm_handler._OD[3, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 3, bool(x))),
                                           ("OD5",
                                            lambda: controller.comm_handler._OD[4, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 4, bool(x))),
                                           ("OD6",
                                            lambda: controller.comm_handler._OD[5, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 5, bool(x))),
                                            columns = 3)

        self.ODDataViewMedia = PlotDataDisplayWidget(self, controller,
                                           ("Media OD1",
                                            lambda: controller.comm_handler._OD_media[0, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 0, bool(x))),
                                           ("Media OD2",
                                            lambda: controller.comm_handler._OD_media[1, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 1, bool(x))),
                                           ("Media OD3",
                                            lambda: controller.comm_handler._OD_media[2, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 2, bool(x))),
                                           ("Media OD4",
                                            lambda: controller.comm_handler._OD_media[3, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 3, bool(x))),
                                           ("Media OD5",
                                            lambda: controller.comm_handler._OD_media[4, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 4, bool(x))),
                                           ("Media OD6",
                                            lambda: controller.comm_handler._OD_media[5, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 5, bool(x))),
                                            columns = 3)

        self.tempGraph = LineGraphWidget(self, controller,
                                    (lambda: (controller.comm_handler._Temp_times[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable[0]
                                     else np.array([]),
                                     controller.comm_handler._TempIR[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]), "Temp IR"),
                                    (lambda: (controller.comm_handler._Temp_times[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable[1]
                                     else np.array([]),
                                     controller.comm_handler._Temp[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]), "Analogue Temp"),
                                    (lambda: (controller.comm_handler._Temp_times_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable_media[0]
                                     else np.array([]),
                                     controller.comm_handler._TempIR_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]), "Media Temp IR"),
                                    (lambda: (controller.comm_handler._Temp_times_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable_media[1]
                                     else np.array([]),
                                     controller.comm_handler._Temp_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]), "Media Analogue Temp"),
                                    title="Temperature", xAxis="Time(s)", yAxis="Temperature(°C)",figureSize = (8,3))

        self.ODGraph = LineGraphWidget(self, controller,
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[0]
                                            else np.array([]),
                                            controller.comm_handler._OD[0, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD1"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[1]
                                            else np.array([]),
                                            controller.comm_handler._OD[1, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD2"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[2]
                                            else np.array([]),
                                            controller.comm_handler._OD[2, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD3"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[3]
                                            else np.array([]),
                                            controller.comm_handler._OD[3, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD4"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[4]
                                            else np.array([]),
                                            controller.comm_handler._OD[4, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD5"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[5]
                                            else np.array([]),
                                            controller.comm_handler._OD[5, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD6"),
                                  title="Optical Density", xAxis="Time(s)", yAxis="Optical Density",figureSize = (8,3))

        self.ODGraphMedia = LineGraphWidget(self, controller,
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[0]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[0, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD1"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[1]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[1, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD2"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[2]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[2, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD3"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[3]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[3, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD4"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[4]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[4, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD5"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[5]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[5, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD6"),
                                  title="Optical Density Media Sensor", xAxis="Time(s)", yAxis="Optical Density",figureSize = (8,3))

        self.combinedODTempGraph = LineGraph2AxisWidget(self, controller,
                                  (lambda: (controller.comm_handler._Temp_times[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]
                                            if controller.comm_handler._Temp_plot_enable[0]
                                            else np.array([]),
                                            controller.comm_handler._TempIR[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]), "Temp IR", True),
                                            (lambda: (controller.comm_handler._Temp_times[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]
                                            if controller.comm_handler._Temp_plot_enable[1]
                                            else np.array([]),
                                            controller.comm_handler._Temp[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]), "Analogue Temp", True),
                                            (lambda: (controller.comm_handler._Temp_times_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]
                                            if controller.comm_handler._Temp_plot_enable_media[0]
                                            else np.array([]),
                                            controller.comm_handler._TempIR_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]), "Media Temp IR", True),
                                            (lambda: (controller.comm_handler._Temp_times_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]
                                            if controller.comm_handler._Temp_plot_enable_media[1]
                                            else np.array([]),
                                            controller.comm_handler._Temp_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]), "Media Analogue Temp", True),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[0]
                                            else np.array([]),
                                            controller.comm_handler._OD[0, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD1", False),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[1]
                                            else np.array([]),
                                            controller.comm_handler._OD[1, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD2", False),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[2]
                                            else np.array([]),
                                            controller.comm_handler._OD[2, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD3", False),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[3]
                                            else np.array([]),
                                            controller.comm_handler._OD[3, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD4", False),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[4]
                                            else np.array([]),
                                            controller.comm_handler._OD[4, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD5", False),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[5]
                                            else np.array([]),
                                            controller.comm_handler._OD[5, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD6", False),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[0]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[0, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD1", False),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[1]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[1, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD2", False),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[2]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[2, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD3", False),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[3]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[3, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD4", False),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[4]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[4, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD5", False),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[5]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[5, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD6", False),
                                  title="Combined Readings", xAxis="Time(s)", yAxis1 = "Temperature(°C)", yAxis2="Optical Density", figureSize = (8,5))


        graph_carosel_btns = ButtonStackWidget(self, controller,
                                      ("End Run","End Run", lambda x: controller.comm_handler.set_Status(
                                                                    3)),
                                      (" /\ ", " /\ ", lambda x: self.update_data(increment = -1)),
                                      ("=", ">", lambda x: self.pause_play_graphs(x), True),
                                      (" \/ "," \/ ", lambda x: self.update_data(increment = 1)))
        graph_carosel_btns.grid(row=0, column=4, rowspan = 4, sticky="NSEW")

        self.pause_play_graphs(True)
        self.update_data()

    def pause_play_graphs(self, active):
        if active:
            self.lastGraphChange = time.time()
        else:
            self.lastGraphChange = None

    def update_data(self, increment = 0):
        if self.lastGraphChange is not None and (time.time() - self.lastGraphChange > 4) and increment == 0:
            increment = 1
        
        if increment != 0:
            self.lastGraphChange = time.time() if self.lastGraphChange is not None else None
            if(self.curGraph == 0):
                self.tempDataView.grid_forget()
                self.tempGraph.grid_forget()
            elif(self.curGraph == 1):
                self.ODDataView.grid_forget()
                self.ODGraph.grid_forget()
            elif(self.curGraph == 2):
                self.ODDataViewMedia.grid_forget()
                self.ODGraphMedia.grid_forget()    
            elif(self.curGraph == 3):
                self.combinedODTempGraph.grid_forget()            

            self.curGraph = (self.curGraph + increment) % 4
            
            if(self.curGraph == 0):
                self.tempDataView.grid(row=4, column=0, rowspan = 2, columnspan = 4, sticky="NSEW")
                self.tempGraph.grid(row=1, column=0, columnspan = 4, rowspan = 3, sticky="NSEW")
            elif(self.curGraph == 1):
                self.ODDataView.grid(row=4, column=0,rowspan = 2, columnspan = 4, sticky="NSEW")
                self.ODGraph.grid(row=1, column=0, columnspan = 4, rowspan = 3, sticky="NSEW")
            elif(self.curGraph == 2):
                self.ODDataViewMedia.grid(row=4, column=0,rowspan = 2, columnspan = 4, sticky="NSEW")
                self.ODGraphMedia.grid(row=1, column=0, columnspan = 4, rowspan = 3, sticky="NSEW")
            elif(self.curGraph == 3):
                self.combinedODTempGraph.grid(row = 1, column = 0, rowspan = 5, columnspan = 4, sticky = "NSEW")
                
    def update_data_every(self):
        if not self.controller.comm_handler.run_in_progress and self.controller.currentFrame == "ExperimentRun":
            self.controller.show_frame("ExperimentStp")

        

class ExperimentPrepTouchscreen(SubpageScafoldTouchscreen):
    def __init__(self, parent, controller):
        SubpageScafoldTouchscreen.__init__(self, parent, controller)


class OveridesTouchscreen(SubpageScafoldTouchscreen):
    def __init__(self, parent, controller):
        SubpageScafoldTouchscreen.__init__(self, parent, controller)
        pumpControlPannel = pumpControlWidget(self, controller)
        pumpControlPannel.grid(row = 0, column = 0, rowspan = 4, columnspan = 5, sticky = "NSWE")


class ControlTouchscreen(SubpageScafoldTouchscreen):
    def __init__(self, parent, controller):
        SubpageScafoldTouchscreen.__init__(self, parent, controller)
        OD_calibration = groupParameterUpdateWidget(
            self, controller, "OD Calibration", lambda: controller.comm_handler.set_Status(64), ("Gradient", lambda x: controller.comm_handler.set_OD_calibration_gradient(x)), ("Offset", lambda x: controller.comm_handler.set_OD_calibration_offset(x)), ("Reference Absorbance", lambda x: controller.comm_handler.set_OD_reference_absorbance(x)))
        OD_calibration.grid(column=0, row=0,columnspan = 2, rowspan = 3, sticky="NSEW", padx=20, pady=20)

        OD_Control = groupParameterUpdateWidget(
            self, controller, "OD Control", lambda: controller.comm_handler.set_Status(66), ("k_P", lambda x: controller.comm_handler.set_OD_P(x)), ("k_I", lambda x: controller.comm_handler.set_OD_I(x)), ("k_D", lambda x: controller.comm_handler.set_OD_D(x)))
        OD_Control.grid(column=0, row=3, columnspan = 2, rowspan = 3, sticky="NSEW", padx=20, pady=20)

        Temp_calibration = groupParameterUpdateWidget(
            self, controller, "Temperature Calibration", lambda: controller.comm_handler.set_Status(48), ("Gradient", lambda x: controller.comm_handler.set_temp_calibration_gradient(x)), ("Offset", lambda x: controller.comm_handler.set_temp_calibration_offset(x)))
        Temp_calibration.grid(column=2, row=0, columnspan = 2, rowspan = 3, sticky="NSEW", padx=20, pady=20)

        Temp_Control = groupParameterUpdateWidget(
            self, controller, "Temperature Control", lambda: controller.comm_handler.set_Status(50), ("k_P", lambda x: controller.comm_handler.set_temp_P(x)), ("k_I", lambda x: controller.comm_handler.set_temp_I(x)), ("k_D", lambda x: controller.comm_handler.set_temp_D(x)))
        Temp_Control.grid(column=2, row=3, columnspan = 2, rowspan = 3,sticky="NSEW", padx=20, pady=20)


class FossilRecordTouchscreen(SubpageScafoldTouchscreen):
    def __init__(self, parent, controller):
        SubpageScafoldTouchscreen.__init__(self, parent, controller)


class SettingsTouchscreen(SubpageScafoldTouchscreen):
    def __init__(self, parent, controller):
        SubpageScafoldTouchscreen.__init__(self, parent, controller)


class Keyboard(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=1)
        self.grid_columnconfigure(3, weight=1)
        self.grid_columnconfigure(4, weight=1)

        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self.grid_rowconfigure(4, weight=1)

        self.displayStringVar = tk.StringVar()
        display = tk.Entry(self, textvariable=self.displayStringVar, font=(
            "Calibri", 13), width=5)

        display.grid(row=0, column=0, columnspan=5, sticky="NSEW")

        def stingAppend(val):
            self.displayStringVar.set(self.displayStringVar.get() + val)

        numpad = ButtonStackWidget(self, controller,
                                   ("1", "1", lambda x: stingAppend("1")), ("2", "2",
                                                                            lambda x: stingAppend("2")), ("3", "3", lambda x: stingAppend("3")),
                                   ("4", "4", lambda x: stingAppend("4")), ("5", "5",
                                                                            lambda x: stingAppend("5")), ("6", "6", lambda x: stingAppend("6")),
                                   ("7", "7", lambda x: stingAppend("7")), ("8", "8",
                                                                            lambda x: stingAppend("8")), ("9", "9", lambda x: stingAppend("9")),
                                   (".", ".", lambda x: stingAppend(".")), ("0", "0",
                                                                            lambda x: stingAppend("0")), ("-", "-", lambda x: stingAppend("-")),
                                   columns=3)
        numpad.grid(column=0, row=1, columnspan=4, rowspan=4, sticky="NSEW")

        entrybuttons = ButtonStackWidget(self, controller,
                                         ("<-", "<-", lambda x: self.displayStringVar.set(self.displayStringVar.get()[:-1])), ("Enter", "Enter", lambda x: controller.closeKeyboard(True, self.displayStringVar.get())), ("Cancel", "Cancel", lambda x: controller.closeKeyboard(False, "")))
        entrybuttons.grid(column=4, row=1, rowspan=4, sticky="NSEW")

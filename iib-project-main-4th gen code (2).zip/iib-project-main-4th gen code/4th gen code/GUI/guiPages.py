import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from functools import partial

# import schemdraw
# import schemdraw.elements as elm

import matplotlib.pyplot as plt
import numpy as np

import random

import os

from GUI.guiWidgets import *


class PageScafold(tk.Frame):
    """
    Generic page scafold that all pages should inherit from
    Adds a menu bar and configures the top row 

    parent -- frame for which this widget is the direct child of (ie where it was instantiated) 
    controller -- root controller object (windows)
    """

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.grid_rowconfigure(0, weight=0, minsize=20)

        label = MenuBarWidget(self, controller)
        label.grid(row=0, column=0, columnspan=2, sticky="NEW")


class Homepage(PageScafold):
    def __init__(self, parent, controller):
        PageScafold.__init__(self, parent, controller)

        self.grid_columnconfigure(0, weight=2)
        self.grid_columnconfigure(1, weight=1, pad=10)

        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self.grid_rowconfigure(4, weight=1)

        communicationsDataView = DataDisplayWidget(self, controller, ("PC Status", lambda: controller.comm_handler._Status),
                                                   ("Device Status", lambda: controller.comm_handler._DeviceStatus), columns=2)
        communicationsDataView.grid(row=1, column=0, sticky="NSEW")

        ODDataView = PlotDataDisplayWidget(self, controller,
                                           ("OD1",
                                            lambda: controller.comm_handler._OD[0, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 0, bool(x))),
                                           ("Media OD1",
                                            lambda: controller.comm_handler._OD_media[0, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 0, bool(x))),
                                           ("OD2",
                                            lambda: controller.comm_handler._OD[1, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 1, bool(x))),
                                           ("Media OD2",
                                            lambda: controller.comm_handler._OD_media[1, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 1, bool(x))),
                                           ("OD3",
                                            lambda: controller.comm_handler._OD[2, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 2, bool(x))),
                                           ("Media OD3",
                                            lambda: controller.comm_handler._OD_media[2, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 2, bool(x))),
                                           ("OD4",
                                            lambda: controller.comm_handler._OD[3, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 3, bool(x))),
                                           ("Media OD4",
                                            lambda: controller.comm_handler._OD_media[3, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 3, bool(x))),
                                           ("OD5",
                                            lambda: controller.comm_handler._OD[4, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 4, bool(x))),
                                           ("Media OD5",
                                            lambda: controller.comm_handler._OD_media[4, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 4, bool(x))),
                                           ("OD6",
                                            lambda: controller.comm_handler._OD[5, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD", 5, bool(x))),
                                           ("Media OD6",
                                            lambda: controller.comm_handler._OD_media[5, -1],
                                            lambda x: controller.comm_handler.set_plot_bools("OD Media", 5, bool(x))),
                                           columns=2)
        ODDataView.grid(row=2, column=0, sticky="NSEW")

        tempDataView = PlotDataDisplayWidget(self, controller,
                                             ("Temperature IR",
                                              lambda: controller.comm_handler._TempIR[-1] if len(
                                                  controller.comm_handler._TempIR) > 0 else "nan",
                                              lambda x: controller.comm_handler.set_plot_bools("Temp", 0, bool(x))),
                                             ("Temperature Immersed",
                                              lambda: controller.comm_handler._Temp[-1] if len(
                                                  controller.comm_handler._Temp) > 0 else "nan",
                                              lambda x: controller.comm_handler.set_plot_bools("Temp", 1, bool(x))),
                                             ("Media Temperature IR",
                                              lambda: controller.comm_handler._TempIR_media[-1] if len(
                                                  controller.comm_handler._TempIR_media) > 0 else "nan",
                                              lambda x: controller.comm_handler.set_plot_bools("Temp Media", 0, bool(x))),
                                             ("Media Temperature Immersed",
                                              lambda: controller.comm_handler._Temp_media[-1] if len(
                                                  controller.comm_handler._Temp_media) > 0 else "nan",
                                              lambda x: controller.comm_handler.set_plot_bools("Temp Media", 1, bool(x))),
                                             columns=2)
        tempDataView.grid(row=3, column=0, sticky="NSEW")

        pumpControl = pumpControlWidget(self, controller)
        pumpControl.grid(row=4, column=0, sticky="NSEW", pady=10)

        ODGraph = LineGraphWidget(self, controller,
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[0]
                                            else np.array([]),
                                            controller.comm_handler._OD[0, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD1"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[1]
                                            else np.array([]),
                                            controller.comm_handler._OD[1, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD2"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[2]
                                            else np.array([]),
                                            controller.comm_handler._OD[2, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD3"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[3]
                                            else np.array([]),
                                            controller.comm_handler._OD[3, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD4"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[4]
                                            else np.array([]),
                                            controller.comm_handler._OD[4, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD5"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[5]
                                            else np.array([]),
                                            controller.comm_handler._OD[5, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD6"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[0]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[0, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD1"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[1]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[1, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD2"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[2]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[2, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD3"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[3]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[3, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD4"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[4]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[4, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD5"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[5]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[5, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD6"),
                                  title="Optical Density", xAxis="Time(s)", yAxis="Optical Density")

        ODGraph.grid(row=1, column=1, rowspan=2, sticky="NSW")

        tempGraph = LineGraphWidget(self, controller,
                                    (lambda: (controller.comm_handler._Temp_times[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable[0]
                                     else np.array([]),
                                     controller.comm_handler._TempIR[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]), "Temp IR"),
                                    (lambda: (controller.comm_handler._Temp_times[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable[1]
                                     else np.array([]),
                                     controller.comm_handler._Temp[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]), "Analogue Temp"),
                                    (lambda: (controller.comm_handler._Temp_times_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable_media[0]
                                     else np.array([]),
                                     controller.comm_handler._TempIR_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]), "Media Temp IR"),
                                    (lambda: (controller.comm_handler._Temp_times_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable_media[1]
                                     else np.array([]),
                                     controller.comm_handler._Temp_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]), "Media Analogue Temp"),
                                    title="Temperature", xAxis="Time(s)", yAxis="Temperature(°C)")

        tempGraph.grid(row=3, column=1, rowspan=2, sticky="NSW")


class ExperimentPage(PageScafold):
    def __init__(self, parent, controller):
        PageScafold.__init__(self, parent, controller)

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self.grid_rowconfigure(4, weight=1)

        ODGraph = LineGraphWidget(self, controller,
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[0]
                                            else np.array([]),
                                            controller.comm_handler._OD[0, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD1"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[1]
                                            else np.array([]),
                                            controller.comm_handler._OD[1, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD2"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[2]
                                            else np.array([]),
                                            controller.comm_handler._OD[2, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD3"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[3]
                                            else np.array([]),
                                            controller.comm_handler._OD[3, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD4"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[4]
                                            else np.array([]),
                                            controller.comm_handler._OD[4, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD5"),
                                  (lambda: (controller.comm_handler._OD_times[controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable[5]
                                            else np.array([]),
                                            controller.comm_handler._OD[5, :][controller.comm_handler._OD_times > controller.comm_handler._OD_plot_min_t]), "OD6"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[0]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[0, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD1"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[1]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[1, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD2"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[2]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[2, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD3"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[3]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[3, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD4"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[4]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[4, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD5"),
                                  (lambda: (controller.comm_handler._OD_times_media[controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]
                                            if controller.comm_handler._OD_plot_enable_media[5]
                                            else np.array([]),
                                            controller.comm_handler._OD_media[5, :][controller.comm_handler._OD_times_media > controller.comm_handler._OD_plot_min_t]), "Media OD6"),
                                  title="Optical Density", xAxis="Time(s)", yAxis="Optical Density")
        ODGraph.grid(row=1, column=0, sticky="NSW")

        tempGraph = LineGraphWidget(self, controller,
                                    (lambda: (controller.comm_handler._Temp_times[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable[0]
                                     else np.array([]),
                                     controller.comm_handler._TempIR[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]), "Temp IR"),
                                    (lambda: (controller.comm_handler._Temp_times[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable[1]
                                     else np.array([]),
                                     controller.comm_handler._Temp[controller.comm_handler._Temp_times > controller.comm_handler._Temp_plot_min_t]), "Analogue Temp"),
                                    (lambda: (controller.comm_handler._Temp_times_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable_media[0]
                                     else np.array([]),
                                     controller.comm_handler._TempIR_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]), "Media Temp IR"),
                                    (lambda: (controller.comm_handler._Temp_times_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]
                                     if controller.comm_handler._Temp_plot_enable_media[1]
                                     else np.array([]),
                                     controller.comm_handler._Temp_media[controller.comm_handler._Temp_times_media > controller.comm_handler._Temp_plot_min_t]), "Media Analogue Temp"),
                                    title="Temperature", xAxis="Time(s)", yAxis="Temperature(°C)")

        tempGraph.grid(row=1, column=1, sticky="NSW")


class ExperimentSetupPage(PageScafold):
    def __init__(self, parent, controller):
        PageScafold.__init__(self, parent, controller)

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.grid_rowconfigure(1, weight=0, minsize=20)
        self.grid_rowconfigure(2, weight=1)

        # should add a scrollable element but it can only act on a canvas so would have to stack the table frame inside the canvas.

        buttons = ButtonStackWidget(self, controller,
                                    ("Upload Sequence", "Upload Sequence",
                                     lambda x: controller.comm_handler.set_Status(32)),
                                    ("Stop Run", "Start Run",
                                     lambda x: controller.comm_handler.set_Status(
                                         2)
                                     if x else controller.comm_handler.set_Status(3)),
                                    ("Referance OD", "Referance OD",
                                     lambda x: controller.comm_handler.set_Status(68)),
                                    ("Referance Media OD", "Referance Media OD",
                                     lambda x: controller.comm_handler.set_Status(69)),
                                    ("Referance Both OD", "Referance Both OD",
                                     lambda x: controller.comm_handler.set_Status(70)),
                                    ("Save Sequence", "Save Sequence",
                                     lambda x: controller.comm_handler.save_sequence(
                                         tk.filedialog.asksaveasfilename(initialdir=os.getcwd(),
                                                                         title="Select a File",
                                                                         filetypes=(("Sequnce files",
                                                                                    "*.csv*"),
                                                                                    ("All files",
                                                                                    "*.*"))))),
                                    ("Load Sequence", "Load Sequence",
                                     lambda x: controller.comm_handler.load_sequence(
                                         tk.filedialog.askopenfilename(initialdir=os.getcwd(),
                                                                       title="Select a File",
                                                                       filetypes=(("Sequnce files",
                                                                                  "*.csv*"),
                                                                                  ("All files",
                                                                                  "*.*"))))),
                                    columns=7)

        buttons.grid(row=1, column=0, columnspan=2, sticky="NSEW")

        sequenceTable = EntryTableWidget(
            self, controller, [("No", int, 0), ("Time Trigger", float, 5000000), ("Temp Trigger", float, 200), ("OD", float, 200),
                               ("", float, 200), ("T", float, 200), ("ri", float,
                                                                     200), ("gg", float, 200), ("er", float, 200),
                               ("Target Temp", float, 0), ("OD Sensor", int, 2), ("Target OD", float, 200), ("OD Drift", float, 0), ("Next", int, 0)])
        sequenceTable.grid(row=2, column=0, columnspan=2, sticky="NEW")


class ControlPage(PageScafold):
    def __init__(self, parent, controller):
        PageScafold.__init__(self, parent, controller)

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)
        self.grid_rowconfigure(3, weight=1)

        OD_calibration = groupParameterUpdateWidget(
            self, controller, "OD Calibration", lambda: controller.comm_handler.set_Status(64), ("Gradient", lambda x: controller.comm_handler.set_OD_calibration_gradient(x)), ("Offset", lambda x: controller.comm_handler.set_OD_calibration_offset(x)), ("Reference Absorbance", lambda x: controller.comm_handler.set_OD_reference_absorbance(x)))
        OD_calibration.grid(column=0, row=1, sticky="NSEW", padx=20, pady=20)

        OD_target = groupParameterUpdateWidget(
            self, controller, "OD Target", lambda: controller.comm_handler.set_Status(65), ("Target", lambda x: controller.comm_handler.set_OD_target(x)))
        OD_target.grid(column=0, row=2, sticky="NSEW", padx=20, pady=20)

        OD_Control = groupParameterUpdateWidget(
            self, controller, "OD Control", lambda: controller.comm_handler.set_Status(66), ("k_P", lambda x: controller.comm_handler.set_OD_P(x)), ("k_I", lambda x: controller.comm_handler.set_OD_I(x)), ("k_D", lambda x: controller.comm_handler.set_OD_D(x)))
        OD_Control.grid(column=0, row=3, sticky="NSEW", padx=20, pady=20)

        Temp_calibration = groupParameterUpdateWidget(
            self, controller, "Temperature Calibration", lambda: controller.comm_handler.set_Status(48), ("Gradient", lambda x: controller.comm_handler.set_temp_calibration_gradient(x)), ("Offset", lambda x: controller.comm_handler.set_temp_calibration_offset(x)))
        Temp_calibration.grid(column=1, row=1, sticky="NSEW", padx=20, pady=20)

        Temp_target = groupParameterUpdateWidget(
            self, controller, "Temperature Target", lambda: controller.comm_handler.set_Status(49), ("Target", lambda x: controller.comm_handler.set_temp_target(x)))
        Temp_target.grid(column=1, row=2, sticky="NSEW", padx=20, pady=20)

        Temp_Control = groupParameterUpdateWidget(
            self, controller, "Temperature Control", lambda: controller.comm_handler.set_Status(50), ("k_P", lambda x: controller.comm_handler.set_temp_P(x)), ("k_I", lambda x: controller.comm_handler.set_temp_I(x)), ("k_D", lambda x: controller.comm_handler.set_temp_D(x)))
        Temp_Control.grid(column=1, row=3, sticky="NSEW", padx=20, pady=20)


class SettingsPage(PageScafold):
    def __init__(self, parent, controller):
        PageScafold.__init__(self, parent, controller)

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.grid_rowconfigure(1, weight=1)

        settingsStack = dataInputStackWidget(
            self, controller, ("OD Plots Start Time",
                               lambda x: controller.comm_handler.set_od_plot_start_time(x)),
            ("Temperature Plots Start Time", lambda x: controller.comm_handler.set_temp_plot_start_time(x)))
        settingsStack.grid(row=1, column=0, sticky="NEW")


class FossilRecordPage(PageScafold):
    def __init__(self, parent, controller):
        PageScafold.__init__(self, parent, controller)

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.grid_rowconfigure(0,weight = 1)
        self.grid_rowconfigure(1,weight = 1)
        self.grid_rowconfigure(2,weight = 1)
        self.grid_rowconfigure(3,weight = 1)

        valveControl = valveControlWidget(self,controller)
        valveControl.grid(row = 0, column = 0)

        armPos = DataDisplayWidget(self,controller, ("x", lambda: 0 if controller.comm_handler._robot_pose is None else controller.comm_handler._robot_pose[0]),
                                                    ("y", lambda: 0 if controller.comm_handler._robot_pose is None else controller.comm_handler._robot_pose[1]),
                                                    ("z", lambda: 0 if controller.comm_handler._robot_pose is None else controller.comm_handler._robot_pose[2]))

        armPos.grid(row = 1, column = 0)



# class Homepage1Touchscreen(tk.Frame):
#     def __init__(self, parent, controller):
#         tk.Frame.__init__(self, parent)

#         self.grid_columnconfigure(0, weight=1)

#         self.grid_rowconfigure(0, weight=1)

#         navButtons = ButtonStackWidget(
#             self, controller, *[(str(i), str(i), lambda x: i) for i in range(6)], columns=3)
#         navButtons.grid(row=0, column=0, sticky="NSEW")


# class Keyboard(tk.Frame):
#     def __init__(self, parent, controller):
#         tk.Frame.__init__(self, parent)

#         self.grid_columnconfigure(0, weight=1)
#         self.grid_columnconfigure(1, weight=1)
#         self.grid_columnconfigure(2, weight=1)
#         self.grid_columnconfigure(3, weight=1)
#         self.grid_columnconfigure(4, weight=1)

#         self.grid_rowconfigure(0, weight=1)
#         self.grid_rowconfigure(1, weight=1)
#         self.grid_rowconfigure(2, weight=1)
#         self.grid_rowconfigure(3, weight=1)
#         self.grid_rowconfigure(4, weight=1)

#         self.displayStringVar = tk.StringVar()
#         display = tk.Entry(self, textvariable=self.displayStringVar, font=(
#             "Calibri", 13), width=5)

#         display.grid(row=0, column=0, columnspan=5, sticky="NSEW")

#         def stingAppend(val):
#             self.displayStringVar.set(self.displayStringVar.get() + val)

#         numpad = ButtonStackWidget(self, controller,
#                                    ("1", "1", lambda x: stingAppend("1")), ("2", "2",
#                                                                             lambda x: stingAppend("2")), ("3", "3", lambda x: stingAppend("3")),
#                                    ("4", "4", lambda x: stingAppend("4")), ("5", "5",
#                                                                             lambda x: stingAppend("5")), ("6", "6", lambda x: stingAppend("6")),
#                                    ("7", "7", lambda x: stingAppend("7")), ("8", "8",
#                                                                             lambda x: stingAppend("8")), ("9", "9", lambda x: stingAppend("9")),
#                                    (".", ".", lambda x: stingAppend(".")), ("0", "0",
#                                                                             lambda x: stingAppend("0")), ("<-", "<-", lambda x: self.displayStringVar.set(self.displayStringVar.get()[:-1])),
#                                    columns=3)
#         numpad.grid(column=0, row=1, columnspan=4, rowspan=4, sticky="NSEW")

#         entrybuttons = ButtonStackWidget(self, controller,
#                                          ("Enter", "Enter", lambda x: controller.closeKeyboard(True, self.displayStringVar.get())), ("Cancel", "Cancel", lambda x: controller.closeKeyboard(False, "")))
#         entrybuttons.grid(column=4, row=1, rowspan=4, sticky="NSEW")


def tmpRandomNumGen():
    return random.randint(0, 100)


def tmpGraphDataGen():
    xData = []
    yData = []
    for i in range(6):
        xData.append(tmpRandomNumGen())
        yData.append(tmpRandomNumGen())

    tmpX = [0, 1, 2, 3, 4, 5, 6]
    tmpY = [0, 1, 2, 3, 4, 5, 6]
    # return (tmpX,tmpY)
    return (xData, yData)

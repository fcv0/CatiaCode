fossilRecordConnected = False
if fossilRecordConnected:
    import threading
    from roboticArm.robotArm import *
    os.chdir(os.path.abspath(os.path.dirname(__file__)))
from GUI.guiRoot import *
from Communication_class import *

timeFossilSampling = True
fossilStartupSleep = 1800
fossilInterval = 1800

ODFossilSampling = False
fossilODSamplePoints = [0.26*(x+1) for x in range(23)] 

lastFossilSample = time.time()
pumpStarted = False
valveTriggered = False

if __name__ == "__main__":
    comm_handler = Communication()
    print("communication initialised")
    guiObj = windows(comm_handler, touchscreen = False)
    print("gui initialised")
    if fossilRecordConnected:
        fossilRecord = FRecord()
        fossilRecordThread = threading.Thread(target=fossilRecord.ArmMovement, daemon=True)
        fossilRecordThread.start()
        guiObj.fossilRecord = fossilRecord
        print("Fossil Record Initialised")
    else:
        time.sleep(2)
    print("\nsetup complete")
    timePerDataRefresh = 0.5
    last_GUI_refresh = time.time()
    while True:
        cur_time = time.time()
        comm_handler.main()
        guiObj.update_idletasks()
        guiObj.update()
        guiObj.update_data_every()
        if cur_time - last_GUI_refresh > timePerDataRefresh:
            guiObj.update_data()
        if not fossilRecordConnected:
            continue
        comm_handler._robot_pose = fossilRecord.getArmPose()
        if fossilRecord.changeValve:
            if not valveTriggered:
                print("triggering valve {} to".format(fossilRecord.activeValve), fossilRecord.valveState)
                if(fossilRecord.valveState):
                    comm_handler._pinch_valve_states |= (1 << fossilRecord.activeValve)
                else:
                    comm_handler._pinch_valve_states &= ~(1 << fossilRecord.activeValve)
                comm_handler.set_Status(6)
                valveTriggered = True
            else:
                fossilRecord.changeValve = False   #add proper check
                valveTriggered = False
        elif fossilRecord.pumpFossilSample:
            print(" Pumping Sample: Pump:{}, Speed:{}".format(fossilRecord.activePump, comm_handler._Pump[fossilRecord.activePump, -1]), end = "\r")
            if not comm_handler._pumps_on_delay[fossilRecord.activePump]:
                comm_handler._pump_delay_speed = fossilRecord.pumpSpeed
                comm_handler._pumps_on_delay[fossilRecord.activePump] = True
                comm_handler._pump_delay_pump = fossilRecord.activePump
                comm_handler._pump_delay_time = fossilRecord.pumpTime
                comm_handler.set_Status(5)
            else:
                if not pumpStarted:
                    pumpStarted = not(comm_handler._Pump[fossilRecord.activePump, -1] == 0)
                elif comm_handler._Pump[fossilRecord.activePump, -1] == 0:
                    fossilRecord.pumpFossilSample = False
                    comm_handler._pumps_on_delay[fossilRecord.activePump] = False
                    pumpStarted = False
                    print("                                               ", end = "\r")
        elif not fossilRecord.armActive and fossilRecord.wellFull.all():
            fossilRecordConnected = False
        elif not fossilRecord.armActive and ((timeFossilSampling and cur_time - lastFossilSample > fossilInterval + fossilStartupSleep) or (ODFossilSampling and comm_handler._OD[1, -1] > fossilODSamplePoints[0])):
            print("Taking Sample")
            if(ODFossilSampling and comm_handler._OD[1, -1] > fossilODSamplePoints[0]):
                ODFossilSampling = ODFossilSampling[1:]
                if(len(ODFossilSampling) == 0):
                    ODFossilSampling = False
            if(cur_time - lastFossilSample > fossilInterval + fossilStartupSleep):
                fossilStartupSleep = 0
            fossilRecord.armActive = True
            lastFossilSample = cur_time
            comm_handler.log_info(np.array([comm_handler.device_time, fossilRecord.colIDX, fossilRecord.rowIDX]), [],
                      "fossil_record_log.csv", overwrite=False)

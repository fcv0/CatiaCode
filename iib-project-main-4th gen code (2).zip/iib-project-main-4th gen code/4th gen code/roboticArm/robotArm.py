if __name__ == '__main__':
    import DobotDllType as dType
else:
    from roboticArm import DobotDllType as dType
import os, time
import numpy as np
from serial.tools import list_ports
import pandas as pd

class FRecord:
    HOMED, armActive, pumpFossilSample, changeValve = False, False, False, False
    # startCoords = [[182.8284, 30.2691, -86.8775]] # x, y, z, r; let r = 0
    startCoords = [[191.4331, 30.0636, 43.7916]] # x, y, z, r; let r = 0   
    # startCoords = [[190.2081, 32.6562, 25]] # x, y, z, r; let r = 0   
    wasteCoords = [[9.6484, -195.6732, 64.6932]] # Need a method to detect the waste coords or perhaps build an extension to the plate so that predefine positions can be had. 
    xOffset, yOffset = (285.0348 - startCoords[0][0])/5, -(-32.4323 - startCoords[0][1])/3
    secondaryYOffset, secondaryXOffset = (29.3916 - startCoords[0][1])/5, (191.5061 - startCoords[0][0])/3
    rowIDX, colIDX, robotState, activePump, pumpSpeed = 0, 0, 0, 1, -255
    rows, columns = 4,6
    wellPositions = np.zeros((rows,columns,3))
    wellPositionsAssigned = np.zeros((rows,columns), dtype = bool)
    wellFull = np.zeros((rows,columns), dtype = bool)

    tempSensingWell = (0,5)
    wellFull[tempSensingWell[0],tempSensingWell[1]] = True 
    wellFull[0,0] = True 
    wellFull[0,1] = True 
    wellFull[3,0] = True 
    wellFull[3,1] = True 

    def __init__(self) -> None:
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        wp = pd.read_csv("wellPositions.csv")
        for i in range(self.wellPositions.shape[0]):
            for j in range(self.wellPositions.shape[1]):
                pos = wp.loc[np.logical_and(wp['row'] == i, wp['column'] == j)]
                # pos = wp[np.logical_and(wp["row"] == i and wp["column"] == j)]
                self.wellPositions[i,j] = np.array([pos["x"],pos["y"],pos["z"]], dtype = float).reshape(-1)


        self.api, self.state = self.connectTo()
        if (self.state == dType.DobotConnect.DobotConnect_NoError):
            dType.ClearAllAlarmsState(self.api)
            dType.SetQueuedCmdClear(self.api)
            ## apply settings to instance
            if not self.HOMED:
                self.HOMED = self._HomeInstance
            self.changeValve = False
            self.pumpFossilSample = False
            while(self.wellFull[self.rowIDX,self.colIDX]):
                self.colIDX += 1    
                if self.colIDX >= self.columns:
                    self.colIDX = 0
                    self.rowIDX += 1
                if self.rowIDX >= self.rows:
                    self.rowIDX = 0
            # self.DryArmMovement()

    @staticmethod
    def connectTo():
        CON_STR = {dType.DobotConnect.DobotConnect_NoError:  "DobotConnect_NoError", dType.DobotConnect.DobotConnect_NotFound: "DobotConnect_NotFound", dType.DobotConnect.DobotConnect_Occupied: "DobotConnect_Occupied"}
        api = dType.load()
        ports = list_ports.comports(include_links=False)
        for port in ports:
            if port.vid == 4292:
                PORT = port
        state = dType.ConnectDobot(api, f"{PORT.name}", 115200)[0]
        print("Connect status: ", CON_STR[state])
        return api, state

    @property
    def _HomeInstance(self, ) -> None:
        dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVLXYZMode, x=dType.GetPose(self.api)[0], y=dType.GetPose(self.api)[1] , z= dType.GetPose(self.api)[2]+40, rHead=0.0)
        dType.SetHOMEParams(self.api, x=200, y=10, z=100, r=0, isQueued = 1) # r was 200 idk if thats correct ? 
        dType.SetHOMECmdEx(self.api, temp=0, isQueued = 1)
        return True

    def moveArmTo(self,pose):
        dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=pose[0], y=self.pose[1], z=self.pose[2], rHead=0.0)

    def getArmPose(self):
        return dType.GetPose(self.api)

    def ArmMovement(self, ) -> None:
        while True:
            if self.robotState == 0 and not self.pumpFossilSample and self.armActive:
                # Pump waste into the waste bottle before new well.
                self.robotState += 1
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2]+50, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2], rHead=0.0)
                self.changeValve, self.activeValve, self.valveState, self.pumpTime, self.pumpFossilSample, self.pumpSpeed = True, 0, True, 30000, True, -255 # Change valve to water, active pinch valve (should only be on atm), valve state (double valve 0 or 1 i.e bool val), pump time needs to be set (in ms ), pumping a sample or pumping something thus halt movements.
            
            if self.robotState == 1 and not self.pumpFossilSample and self.armActive:
                self.robotState += 1
                self.pumpTime, self.pumpFossilSample, self.pumpSpeed = 3000, True, 255

            if self.robotState == 2 and not self.pumpFossilSample and self.armActive:
                # Set a safe position then move over well and pump the real sample.
                self.wellFull[self.rowIDX,self.colIDX] = True
                self.robotState += 1
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2] + 30, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+40, rHead=0.0)
                # dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+17, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+15, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]-2, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2], rHead=0.0)
                self.changeValve, self.pumpTime, self.pumpFossilSample, self.activeValve, self.valveState, self.pumpSpeed = True, 90000, True, 0, True, -255 #ms
                # input()
            if self.robotState == 3 and not self.pumpFossilSample and self.armActive:
                # Valve state and active valve should all be the same from the sample
                # Thus, lets reverse the sample pumping direction back into the main chamber for an undef amount of time then continue the cycle.
                self.robotState += 1
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+15, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+40, rHead=0.0)
                self.pumpTime, self.pumpFossilSample, self.pumpSpeed = 25000, True, 255
            if self.robotState == 4 and not self.pumpFossilSample and self.armActive:
                # Now lets hover over the waste bottle and pump water getting ready for the next sample
                self.robotState += 1
                #dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.startCoords[0][0]+(self.colIDX*self.xOffset)), y=(self.startCoords[0][1]-(self.rowIDX*self.yOffset)), z=self.startCoords[0][2]+40, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2]+30, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2], rHead=0.0)
                self.changeValve, self.pumpTime, self.pumpFossilSample, self.activeValve, self.valveState, self.pumpSpeed = True, 45000, True, 0, False, -255 #ms
            if self.robotState == 5 and not self.pumpFossilSample and self.armActive:
                self.robotState += 1
                self.pumpTime, self.pumpFossilSample, self.pumpSpeed = 3000, True, 255
            if self.robotState == 6 and not self.pumpFossilSample and self.armActive:
                self.robotState += 1
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2]+30, rHead=0.0)
                #dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.startCoords[0][0]+(self.colIDX*self.xOffset)), y=(self.startCoords[0][1]-(self.rowIDX*self.yOffset)), z=self.startCoords[0][2]+40, rHead=0.0)
                self.robotState = 0
                self.armActive = False
                while(self.wellFull[self.rowIDX,self.colIDX]):
                    self.colIDX += 1    
                    if self.colIDX >= self.columns:
                        self.colIDX = 0
                        self.rowIDX += 1
                    if self.rowIDX >= self.rows:
                        self.rowIDX = 0
                    if self.wellFull.all():
                        return
            time.sleep(1/100) # 100 Hz checking freq.

    def DryArmMovement(self, ) -> None:
        self.armActive = True
        while True:
            if self.rowIDX == 0 and self.colIDX == 5:
                self.colIDX = 0
                self.rowIDX += 1
            if self.robotState == 0 and not self.pumpFossilSample and self.armActive:
                # Pump waste into the waste bottle before new well.
                self.robotState += 1
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2]+50, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2], rHead=0.0)
                # self.changeValve, self.activeValve, self.valveState, self.pumpTime, self.pumpFossilSample, self.pumpSpeed = True, 0, True, 30000, True, 255 # Change valve to water, active pinch valve (should only be on atm), valve state (double valve 0 or 1 i.e bool val), pump time needs to be set (in ms ), pumping a sample or pumping something thus halt movements.
            
            if self.robotState == 1 and not self.pumpFossilSample and self.armActive:
                self.robotState += 1
                # self.pumpTime, self.pumpFossilSample, self.pumpSpeed = 3000, True, -255

            if self.robotState == 2 and not self.pumpFossilSample and self.armActive:
                # Set a safe position then move over well and pump the real sample.
                self.robotState += 1
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2] + 30, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+40, rHead=0.0)
                # dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+17, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+15, rHead=0.0)
                # dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]-2, rHead=0.0)
                # dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2], rHead=0.0)
                # self.changeValve, self.pumpTime, self.pumpFossilSample, self.activeValve, self.valveState, self.pumpSpeed = True, 25000, True, 0, True, 255 #ms
                # input()
            if self.robotState == 3 and not self.pumpFossilSample and self.armActive:
                # Valve state and active valve should all be the same from the sample
                # Thus, lets reverse the sample pumping direction back into the main chamber for an undef amount of time then continue the cycle.
                self.robotState += 1
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+15, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.wellPositions[self.rowIDX,self.colIDX,0]), y=(self.wellPositions[self.rowIDX,self.colIDX,1]), z=self.wellPositions[self.rowIDX,self.colIDX,2]+40, rHead=0.0)
                # self.pumpTime, self.pumpFossilSample, self.pumpSpeed = 25000, True, -255
            if self.robotState == 4 and not self.pumpFossilSample and self.armActive:
                # Now lets hover over the waste bottle and pump water getting ready for the next sample
                self.robotState += 1
                #dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.startCoords[0][0]+(self.colIDX*self.xOffset)), y=(self.startCoords[0][1]-(self.rowIDX*self.yOffset)), z=self.startCoords[0][2]+40, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2]+30, rHead=0.0)
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2], rHead=0.0)
                # self.changeValve, self.pumpTime, self.pumpFossilSample, self.activeValve, self.valveState, self.pumpSpeed = True, 45000, True, 0, False, 255 #ms
            if self.robotState == 5 and not self.pumpFossilSample and self.armActive:
                self.robotState += 1
                # self.pumpTime, self.pumpFossilSample, self.pumpSpeed = 3000, True, -255
            if self.robotState == 6 and not self.pumpFossilSample and self.armActive:
                self.robotState += 1
                dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=self.wasteCoords[0][0], y=self.wasteCoords[0][1], z=self.wasteCoords[0][2]+30, rHead=0.0)
                #dType.SetPTPCmdEx(self.api, dType.PTPMode.PTPMOVJXYZMode, x=(self.startCoords[0][0]+(self.colIDX*self.xOffset)), y=(self.startCoords[0][1]-(self.rowIDX*self.yOffset)), z=self.startCoords[0][2]+40, rHead=0.0)
                self.colIDX += 1
                self.robotState = 0
                if self.colIDX >= self.columns:
                    self.colIDX = 0
                    self.rowIDX += 1
                if self.rowIDX >= self.rows:
                    self.rowIDX = 0
                    break
                while(self.wellFull[self.rowIDX,self.colIDX]):
                    self.colIDX += 1    
                    if self.colIDX >= self.columns:
                        self.colIDX = 0
                        self.rowIDX += 1
                    if self.rowIDX >= self.rows:
                        self.rowIDX = 0
                        break
            time.sleep(1/100) # 100 Hz checking freq.
        self.armActive = False

if __name__ == "__main__":
    FRecord()
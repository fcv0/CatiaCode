import matplotlib.pyplot as plt
import numpy as np
import scipy 
import pandas as pd

# z = ax + by + c
# Ax = B
# [x y 1][a;b;c] = z
rows = 4
columns = 6
wellPositions = np.zeros((rows,columns,3))
wellPositionsAssigned = np.zeros((rows,columns), dtype = bool)
specWellSpacing = 18


def extrapolatePoints(wellPoints,wellPointBools,rows,columns):
    points = None
    pointCoords = None
    for i in range(rows):
        for j in range(columns):
            if wellPointBools[i,j]:
                if points is None:
                    points = np.array(wellPoints[i,j]).reshape(1,3)
                    pointCoords = np.array((i,j)).reshape(1,2)
                else:
                    points = np.append(points,np.array(wellPoints[i,j]).reshape(1,3), axis = 0)
                    pointCoords = np.append(pointCoords,np.array((i,j)).reshape(1,2), axis = 0)

    A = np.concatenate((points[:,0:2], np.ones(points.shape[0]).reshape(points.shape[0],1)), axis = 1)
    B = points[:,2]
    x,_,_,_ = scipy.linalg.lstsq(A,B)
    n = np.array([x[0],x[1],-1])

    pointOnPlane = np.array([1,1,x[0] + x[1] + x[2]])
    pointOnPlane2 = np.array([0,0,x[2]])
    pointOnPlane3 = np.array([20,0,20*x[0] + x[2]])
    # n = np.cross(pointOnPlane - pointOnPlane2, pointOnPlane - pointOnPlane3)
    # print(np.dot(n,pointOnPlane - pointOnPlane3))
    # input()
    XX_, YY_ = np.meshgrid(np.linspace(np.min(points[:,0]), np.max(points[:,0]), 20),np.linspace(np.min(points[:,1]), np.max(points[:,1]), 20))

    ZZ_ = x[0]*XX_ + x[1]*YY_ + x[2]

    # ax.scatter3D(XX_,YY_,ZZ_)

    # test_list = np.zeros((25,3))

    # for i in range(25):
    #     test_list[i] = pointOnPlane + n*i

    # ax.scatter3D(test_list[:,0].reshape(-1),test_list[:,1].reshape(-1),test_list[:,2].reshape(-1))

    projectedPoints = points.copy()
    print("points",points)
    for i in range(points.shape[0]):
        projectedPoints[i] = points[i] - np.dot((points[i] - pointOnPlane),n/np.linalg.norm(n))
    print("proj points",projectedPoints)

    def fit_test(curVars, *args):
        # input()
        meanSqErr = 0
        genGrid = generateGrid(*curVars, *args)
        for i in range(points.shape[0]):
            # print("gengrid",genGrid)
            # print("pointcoord",pointCoords[i])
            # print()
            meanSqErr += np.linalg.norm(genGrid[*pointCoords[i]] - points[i])**2
        meanSqErr /= points.shape[0]
        print(meanSqErr)
        return meanSqErr

    def genInitGuess():
        wellSpacing = specWellSpacing
        ##need to add more complex selsciton of wells for 1st guess
        p1,p2,p3 = projectedPoints[0:3]
        p1c,p2c,p3c = pointCoords[0:3]
        p21 = p2 - p1
        p31 = p3 - p1
        p21c = p2c - p1c
        p31c = p3c - p1c
        
        if p21c[1] == 0:
            rowV = p21
        elif p31c[1] == 0:
            rowV = p31
        else:
            rowV = (p21 - p31 * (p21c[1]/p31c[1]))

        n_n = n/np.linalg.norm(n)
        rowV_n = rowV/np.linalg.norm(rowV)

        # print(np.dot(n_n,rowV_n))
        # input()
        
        test_list = np.zeros((25,3))
        test_list2 = np.zeros((25,3))

        for i in range(25):
            test_list[i] = p1 + n_n*i

        # ax.scatter3D(test_list[:,0].reshape(-1),test_list[:,1].reshape(-1),test_list[:,2].reshape(-1))

        for i in range(25):
            test_list2[i] = p1 + rowV_n*i

        # ax.scatter3D(test_list2[:,0].reshape(-1),test_list2[:,1].reshape(-1),test_list2[:,2].reshape(-1))
        # print("normalised vectors",n_n, rowV_n)
        colV = np.cross(n_n,rowV_n)
        colV_n = -colV/np.linalg.norm(colV)
        test_list3 = np.zeros((25,3))

        for i in range(25):
            test_list3[i] = p1 + colV_n*i

        # ax.scatter3D(test_list3[:,0].reshape(-1),test_list3[:,1].reshape(-1),test_list3[:,2].reshape(-1))
        rowVx, rowVz = rowV_n[0], rowV_n[2]
        ori = p1 - wellSpacing*(p1c[0] * rowV_n - p1c[1] * colV_n)
        ori_x, ori_y = ori[0], ori[1]
        print("ori",ori)
        # print("origional",rowV_n)
        return rowVx, rowVz,  wellSpacing,ori_x, ori_y

    def generateGrid(rowVx, rowVz,  wellSpacing, ori_x, ori_y):
        ori_z = x[0]*ori_x + x[1]*ori_y + x[2]
        o = np.array([ori_x,ori_y,ori_z])
        rowVy = -(rowVx*n[0] + rowVz*n[2])/n[1]
        rowV = np.array([rowVx,rowVy,rowVz])
        n_n = n/np.linalg.norm(n)
        rowV_n = rowV/np.linalg.norm(rowV)
        colV = np.cross(n_n,rowV_n)
        colV_n = -colV/np.linalg.norm(colV)
        genWellPositions = np.zeros((rows,columns,3))
        for i in range(rows):
            for j in range(columns):
                genWellPositions[i,j] = o + wellSpacing * (i*rowV_n + j * colV_n)

        # ax.cla()
        # ax.scatter3D(XX,YY,ZZ)
        # ax.scatter3D(genWellPositions[:,:,0].reshape(-1),genWellPositions[:,:,1].reshape(-1),genWellPositions[:,:,2].reshape(-1))
        # plt.pause(0.01)
        # input()
        return genWellPositions

    x_0 = genInitGuess()
    x_f = x_0
    _ = scipy.optimize.minimize(fit_test,x_f[:3], args = (x_f[3:]), tol = 0.01)
    x_f = _["x"]
    val = _["success"]
    print(x_f, val)
    x_f = np.concatenate((x_f, x_0[3:]))
    _ = scipy.optimize.minimize(fit_test,x_f, tol = 0.01)
    x_f = _["x"]
    val = _["success"]
    print(x_f, val)
    finalGrid = generateGrid(*x_f)
    wellPositions[~wellPositionsAssigned] = finalGrid[~wellPositionsAssigned]


# a,b,c, = np.random.random((3))
# print(a,b,c)
# a,b,c = 0.5727563119243583, 0.6608423479170193, 0.8855089246808168

# XX, YY = np.meshgrid(np.linspace(0, specWellSpacing*5, 6),np.linspace(0, specWellSpacing*3, 4))

# ZZ = a*XX + b*YY + c# + np.random.random(XX.shape)

wp = pd.read_csv("roboticArm/wellPositions.csv")
for i in range(wellPositions.shape[0]):
    for j in range(wellPositions.shape[1]):
        pos = wp.loc[np.logical_and(wp['row'] == i, wp['column'] == j)]
        wellPositions[i,j] = np.array([pos["x"],pos["y"],pos["z"]], dtype = float).reshape(-1)

wellPositionsOrigional = wellPositions.copy()
fig = plt.figure()
ax = plt.axes(projection='3d')

# ax.scatter3D(XX,YY,ZZ)
ax.scatter3D(wellPositions[:,:,0].reshape(-1),wellPositions[:,:,1].reshape(-1),wellPositions[:,:,2].reshape(-1))
# plt.pause(0.1)
# input()

# wellPositions[0,0] = [XX[0,0],YY[0,0],ZZ[0,0]]
# wellPositions[3,0] = [XX[3,0],YY[3,0],ZZ[3,0]]
# wellPositions[0,5] = [XX[0,5],YY[0,5],ZZ[0,5]]
# wellPositionsAssigned[0,0] = True
# wellPositionsAssigned[3,0] = True
# wellPositionsAssigned[3,5] = True

wellPositionsAssigned = np.ones_like(wellPositionsAssigned, dtype = bool)

wellPositionsAssigned[0,5] = False
for i in range(24):
    wellPositionsAssigned[np.random.randint(0,4),np.random.randint(0,6)] = False
# print(wellPositionsAssigned)
# input()

# wellPositions[3,5] = [XX[3,5],YY[3,5],ZZ[3,5]]
# wellPositions[2,3] = [XX[2,3],YY[2,3],ZZ[2,3]]
# wellPositionsAssigned[3,5] = True
# wellPositionsAssigned[2,3] = True


extrapolatePoints(wellPositions,wellPositionsAssigned,4,6)

ax.scatter3D(wellPositions[:,:,0].reshape(-1),wellPositions[:,:,1].reshape(-1),wellPositions[:,:,2].reshape(-1))
plt.show()

for i in range(4):
    for j in range(6):
        print(i,j, np.linalg.norm(wellPositionsOrigional[i,j,:2] - wellPositions[i,j,:2]))

print(np.sum(wellPositionsAssigned))
# print("\n\n")
# A = np.concatenate((XX.reshape(1,XX.shape[0]*XX.shape[1]),YY.reshape(1,YY.shape[0]*YY.shape[1]), np.ones((1,XX.shape[0]*XX.shape[1])))).T
# print(A.shape)

# B = ZZ.reshape(1,ZZ.shape[0]*ZZ.shape[1]).T
# x,_,_,_ = scipy.linalg.lstsq(A,B)
# print(x)

# print("\n")

# print(a, x[0])
# print(b, x[1])
# print(c, x[2])

# n = np.array([a,b,-1])






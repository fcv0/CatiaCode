import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# filepath = r"C:\Users\jim-b\Documents\University\IIB\Project\Tests\230905 Calibration OD control failed GC contamination\logs calibend\\"
# filepath = r"C:\Users\jim-b\Documents\University\IIB\Project\Tests\230831 OD Control media ran out\logs end\\"
# filepath = r"C:\Users\jim-b\Documents\University\IIB\Project\Programs\4th gen code\logs\\"
filepath = r"C:\Users\jim-b\Documents\University\IIB\Project\Tests\230919 Pump Dry Test\logs\\"
pump_flow_rate = 17.6  # ml/min
culture_size = 40  # ml

pause_on_plots = False

data_sources = ["heater_log", "heater_media_log", "OD_log", "OD_media_log",
                "pump_log", "target_log", "temp_log", "temp_media_log"]


data_frames = {}
plot_sets = {}

for s in data_sources:
    data_frames[s] = pd.read_csv(filepath + s + ".csv")

    df = data_frames[s]

    t = df[df.keys().to_numpy()[0]].to_numpy()
    for k in df.keys().to_numpy()[1:]:
        plot_sets[s+"_"+k] = (t, df[k].to_numpy())

print(plot_sets.keys())

plt.plot(*plot_sets["OD_log_OD1"])
plt.plot(*plot_sets["target_log_Target OD"])
plt.ylim(0, 1.5)
plt.show()


def main():
    # print("\nGrowth Rates:")

    # t_od_targ = plot_sets["target_log_Target OD"][0]
    # od_targ = plot_sets["target_log_Target OD"][1]
    # t_od_targ_0_3 = t_od_targ[np.logical_and(od_targ > 0.29, od_targ < 0.31)]

    # t_od_0_3_dither = (np.min(t_od_targ_0_3), np.min(
    #     t_od_targ_0_3) + (np.max(t_od_targ_0_3) - np.min(t_od_targ_0_3))/2)
    # t_od_0_3_fixed = (np.min(t_od_targ_0_3) + (np.max(t_od_targ_0_3) -
    #                   np.min(t_od_targ_0_3))/2,   np.max(t_od_targ_0_3))

    # # print(t_od_0_3_dither, t_od_0_3_fixed)
    # print("\nOD 0.3: Dithering")
    # get_dither_growth_rates(t_od_0_3_dither[0], t_od_0_3_dither[1])
    # print("\nOD 0.3: OD Clamp")
    # get_fixed_growth_rates(t_od_0_3_fixed[0], t_od_0_3_fixed[1])

    # t_od_targ = plot_sets["target_log_Target OD"][0]
    # od_targ = plot_sets["target_log_Target OD"][1]
    # t_od_targ_1_0 = t_od_targ[np.logical_and(od_targ > 0.99, od_targ < 1.01)]

    # t_od_1_0_dither = (np.min(t_od_targ_1_0), np.min(
    #     t_od_targ_1_0) + (np.max(t_od_targ_1_0) - np.min(t_od_targ_1_0))/2)
    # t_od_1_0_fixed = (np.min(t_od_targ_1_0) + (np.max(t_od_targ_1_0) -
    #                   np.min(t_od_targ_1_0))/2,   np.max(t_od_targ_1_0) - (15*60*1000))

    # # print(t_od_1_0_dither, t_od_1_0_fixed)
    # print("\n\nOD 1.0: Dithering")
    # get_dither_growth_rates(t_od_1_0_dither[0], t_od_1_0_dither[1])
    # print("\nOD 1.0: OD Clamp")
    # get_fixed_growth_rates(t_od_1_0_fixed[0], t_od_1_0_fixed[1])

    # plt.plot(*plot_sets["OD_log_OD1"])
    # plt.plot(*plot_sets["OD_log_OD2"])
    # plt.plot(*plot_sets["OD_media_log_OD1"])
    # # plt.plot(*plot_sets["OD_media_log_OD2"])
    # plt.plot(*plot_sets["pump_log_Media Transfer"], "b")
    # plt.plot(*plot_sets["pump_log_Waster Pump"], "r--")
    # plt.show()

    t_media_in, media_in = get_total_volume_move(
        plot_sets["pump_log_Media Inlet"], 21.125, 17.625)
    t_media, media = get_total_volume_move(
        plot_sets["pump_log_Media Transfer"], 21.7917, 17.91666667)
    t_waste, waste = get_total_volume_move(
        plot_sets["pump_log_Waster Pump"], 21.70833, 17.75)

    fig, ax1 = plt.subplots()

    # ax1.plot(*plot_sets["OD_log_OD2"])
    # ax1.plot(*plot_sets["OD_media_log_OD1"])
    # ax1.plot(*plot_sets["pump_log_Media Transfer"], "b")
    # ax1.plot(*plot_sets["pump_log_Waster Pump"], "r--")

    ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

    ax2.plot(t_media_in, media_in)
    ax2.plot(t_media, media)
    ax2.plot(t_waste, waste)
    # ax2.plot(plot_sets["pump_log_Media Transfer"][0][1:], media_in - media)
    # ax2.plot(plot_sets["pump_log_Media Transfer"][0][1:], media - waste)

    fig.tight_layout()  # otherwise the right y-label is slightly clipped
    plt.show()


def get_total_volume_move(pump_log, full_speed_fr, two_second_fr):
    t, speed = pump_log

    p_start_times = t[1:][np.logical_and(
        speed[1:] == 255, speed[:-1] == 0)]
    p_end_times = t[1:][np.logical_and(
        speed[1:] == 0, speed[:-1] == 255)]

    if p_start_times.shape[0] > p_end_times.shape[0]:
        p_start_times = p_start_times[:-(p_start_times.shape[0] -
                                      p_end_times.shape[0])]
    p_durations = p_end_times - p_start_times

    for i in range(p_start_times.shape[0]):
        print(p_start_times[i], p_end_times[i], p_durations[i])
    input()

    total_partial = np.cumsum(2/60 * two_second_fr +
                              (p_durations - 2000) * full_speed_fr/60000)

    return p_end_times, total_partial


def get_dither_growth_rates(start_time, end_time):
    t_od = plot_sets["OD_log_OD1"][0]
    od = (plot_sets["OD_log_OD1"][1] - 0.12)

    # plt.plot(t_od,np.where(np.logical_and(t_od > start_time, t_od < end_time),od,np.full_like(od, np.nan)))
    # plt.show()

    t_pump = plot_sets["pump_log_Waster Pump"][0]
    waste_pump = plot_sets["pump_log_Waster Pump"][1]
    media_pump = plot_sets["pump_log_Media Inlet"][1]

    dilution_start_times = t_pump[1:][np.logical_and(
        waste_pump[1:] == 255, waste_pump[:-1] == 0)]
    dilution_end_times = t_pump[1:][np.logical_and(
        media_pump[1:] == 0, media_pump[:-1] == 255)]

    dilution_start_times = dilution_start_times[np.logical_and(
        dilution_start_times > start_time, dilution_start_times < end_time)]
    dilution_end_times = dilution_end_times[np.logical_and(
        dilution_end_times > start_time, dilution_end_times < end_time)]

    while (dilution_start_times.shape[0] != dilution_end_times.shape[0]):
        if (dilution_start_times[0] > dilution_end_times[0]):
            dilution_end_times = dilution_end_times[1:]
        elif (dilution_start_times[-1] > dilution_end_times[-1]):
            dilution_start_times = dilution_start_times[:-1]

    free_growth_start_times = dilution_end_times[:-
                                                 1][dilution_start_times[1:] - dilution_end_times[:-1] > 300000]
    free_growth_end_times = dilution_start_times[1:][np.where(
        np.isin(dilution_end_times, free_growth_start_times))]

    discard_period = 30000

    doubling_times = np.full([], np.nan)

    for i in range(free_growth_start_times.shape[0]):
        t_temp = t_od[np.logical_and(
            t_od > free_growth_start_times[i] + discard_period, t_od < free_growth_end_times[i])]
        od_temp = od[np.logical_and(
            t_od > free_growth_start_times[i] + discard_period, t_od < free_growth_end_times[i])]

        if t_temp.shape[0] == 0:
            continue

        A = np.vstack([t_temp, np.ones(len(t_temp))]).T
        m, c = np.linalg.lstsq(A, np.log(od_temp), rcond=None)[0]

        log_od_fitted = t_temp * m + c

        od_fitted = np.power(np.e, log_od_fitted)

        doubling_time = (np.log(2)/m)/(1000 * 60)

        doubling_times = np.append(doubling_times, doubling_time)

        print("{:.2f} min".format(doubling_time))

        # plt.plot(t_temp, np.log(od_temp), label = doubling_time, color = "b")
        # plt.plot(t_temp, log_od_fitted, color = "r")
        plt.plot(t_temp, od_temp, label=doubling_time, color="b")
        plt.plot(t_temp, od_fitted, color="r")

    print("Average: {:.2f} min".format(np.nanmean(doubling_times)))
    print("Variance: {:.2f} min^2".format(np.nanvar(doubling_times)))
    print("Standard Deviation: {:.2f} min".format(
        np.sqrt(np.nanvar(doubling_times))))

    plt.title("Growth Rates From Dithering")
    plt.ylabel("OD")
    plt.xlabel("Time(ms)")
    plt.legend()
    if pause_on_plots:
        plt.show()
    else:
        plt.pause(0.3)
        plt.clf()


def get_fixed_growth_rates(start_time, end_time):
    discard_period = 10 * 60 * 1000
    t_od = plot_sets["OD_log_OD1"][0]
    od = plot_sets["OD_log_OD1"][1]

    t_pump = plot_sets["pump_log_Waster Pump"][0]
    waste_pump = plot_sets["pump_log_Waster Pump"][1]

    dilution_start_times = t_pump[1:][np.logical_and(
        waste_pump[1:] == 255, waste_pump[:-1] == 0)]
    print("                                 ", dilution_start_times.shape)
    dilution_end_times = t_pump[1:][np.logical_and(
        waste_pump[1:] == 0, waste_pump[:-1] == 255)]

    dilution_start_times = dilution_start_times[np.logical_and(
        dilution_start_times > start_time + discard_period, dilution_start_times < end_time)]
    dilution_end_times = dilution_end_times[np.logical_and(
        dilution_end_times > start_time + discard_period, dilution_end_times < end_time)]

    while (dilution_start_times.shape[0] != dilution_end_times.shape[0]):
        if (dilution_start_times[0] > dilution_end_times[0]):
            dilution_end_times = dilution_end_times[1:]
        elif (dilution_start_times[-1] > dilution_end_times[-1]):
            dilution_start_times = dilution_start_times[:-1]

    dilution_lengths = dilution_end_times - dilution_start_times
    total_dilution_length = np.sum(dilution_lengths)

    total_dilution_volume = (total_dilution_length/1000/60) * pump_flow_rate

    vol_per_min = total_dilution_volume / \
        ((end_time - start_time - discard_period)/1000 / 60)
    doubling_time = (culture_size/2) / vol_per_min

    print("{:.2f} min".format(doubling_time))

    t_temp = t_od[np.logical_and(
        t_od > start_time + discard_period, t_od < end_time)]
    od_temp = od[np.logical_and(
        t_od > start_time + discard_period, t_od < end_time)]

    plt.plot(t_temp, od_temp, label=doubling_time)

    plt.title("Growth Rates From OD Clamping")
    plt.ylabel("OD")
    plt.xlabel("Time(ms)")
    plt.legend()
    if pause_on_plots:
        plt.show()
    else:
        plt.pause(0.3)
        plt.clf()


if __name__ == "__main__":
    main()

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

root_folder = r"C:\Users\jim-b\Documents\University\IIB\Project\Tests\230905 Calibration OD control failed GC contamination\\"

# log_folders = ["logs prestart", "logs poststart", "logs calibend",
#                "logs morning drained", "logs half GC", "logs end of GC"]
log_folders = ["logs calibend",
               "logs morning drained", "logs half GC", "logs end of GC"]
# log_folders = ["logs calibend"]
# log_folders = ["logs half GC", "logs end of GC"]
# filepath = r"C:\Users\jim-b\Documents\University\IIB\Project\Tests\230831 OD Control media ran out\logs end\\"

data_sources = ["heater_log", "heater_media_log", "OD_log", "OD_media_log",
                "pump_log", "target_log", "temp_log", "temp_media_log"]


def get_plot_sets(fp):
    data_frames = {}
    plot_sets = {}

    for s in data_sources:
        data_frames[s] = pd.read_csv(fp + s + ".csv")

        df = data_frames[s]

        t = df[df.keys().to_numpy()[0]].to_numpy()
        for k in df.keys().to_numpy()[1:]:
            plot_sets[s+"_"+k] = (t, df[k].to_numpy())

    return plot_sets


plot_sets_set = []

for f in log_folders:
    plot_sets_set.append(get_plot_sets(root_folder + f + "\\"))

t_ends = np.zeros(len(plot_sets_set))
t_starts = np.zeros(len(plot_sets_set))

for i, ps in enumerate(plot_sets_set):
    last_ts = [ps[k][0][-1] for k in ps.keys()]
    t_ends[i] = np.nanmax(np.array(last_ts).astype(np.int64))
    t_starts[i] = np.nanmin(np.array(last_ts).astype(np.int64))

t_shift = np.cumsum(t_ends)


final_plot_sets = plot_sets_set[0]

for i, ps in enumerate(plot_sets_set[1:]):
    for k in ps.keys():
        t, v = ps[k]
        t += t_shift[i].astype(np.int64)
        final_plot_sets[k] = (
            np.append(final_plot_sets[k][0], t), np.append(final_plot_sets[k][1], v))

# print(final_plot_sets.keys())
print(t_starts)
print(t_ends)
print(t_shift)
plt.plot(range(final_plot_sets["OD_log_OD2"][0].shape[0]),
         final_plot_sets["OD_log_OD2"][0])
plt.show()
plt.plot(*final_plot_sets["OD_log_Absorb 1"])
# plt.plot(*final_plot_sets["OD_log_OD2"])
# plt.plot(*final_plot_sets["OD_media_log_OD2"])
plt.show()

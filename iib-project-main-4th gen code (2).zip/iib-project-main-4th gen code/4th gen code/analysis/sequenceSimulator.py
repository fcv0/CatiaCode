import matplotlib.pyplot as plt
import numpy as np


class SequenceSimulator:

    full_sequence = None

    index_key = {"ID": 0, "Time Trigger": 1, "Temp Trigger": 2, "OD1 Trigger": 3,
                 "OD2 Trigger": 4, "OD3 Trigger": 5, "OD4 Trigger": 6,
                 "OD5 Trigger": 7, "OD6 Trigger": 8, "Target Temp": 9,
                 "OD Sensor": 10, "Target OD": 11, "OD Drift": 12, "Next": 13}

    sequence_t_rows = (None, None)

    def __init__(self, sequance_array, start_time, temp_log, OD1_log, OD2_log, OD3_log, OD4_log, OD5_log, OD6_log):
        self.full_sequence = sequance_array
        self.get_times_of_each_step(
            start_time, temp_log, OD1_log, OD2_log, OD3_log, OD4_log, OD5_log, OD6_log)

        print(self.sequence_t_rows)

    def get_all_sequences_of(self, *index_val_pairs):

        valid_rows = None

        for index, val in index_val_pairs:
            v = self.full_sequence[:, index] == val

            if valid_rows is None:
                valid_rows = v
            else:
                valid_rows = np.logical_and(valid_rows, v)

        return self.full_sequence[valid_rows, :], np.where(valid_rows)[0]

    def get_times_of_each_step(self, start_time, temp_log, OD1_log, OD2_log, OD3_log, OD4_log, OD5_log, OD6_log):
        all_IDs = self.full_sequence[:, self.index_key["ID"]]
        t = [start_time]
        row_num = [0]

        while (True):
            next_ID = self.full_sequence[row_num[-1], self.index_key["Next"]]
            if next_ID == 0:
                break
            next_sequences, next_sequence_row_nums = self.get_all_sequences_of(
                (self.index_key["ID"], next_ID))

            cur_next_row = None
            cur_min_t = None

            for i in range(next_sequences.shape[0]):
                trigger_time = self.get_trigger_time_of_row(
                    next_sequences[i], t[-1], temp_log, OD1_log, OD2_log, OD3_log, OD4_log, OD5_log, OD6_log)

                if cur_min_t is None or trigger_time < cur_min_t:
                    cur_min_t = trigger_time
                    cur_next_row = next_sequence_row_nums[i]

            t.append(cur_min_t)
            row_num.append(cur_next_row)

        self.sequence_t_rows = (np.array(t), np.array(row_num))

        return (np.array(t), np.array(row_num))

    def get_trigger_time_of_row(self, row, start_time, temp_log, OD1_log, OD2_log, OD3_log, OD4_log, OD5_log, OD6_log):
        cur_min_t = row[self.index_key["Time Trigger"]] + start_time

        for i, (ts, log) in enumerate([temp_log, OD1_log, OD2_log, OD3_log, OD4_log, OD5_log, OD6_log]):
            trimmed_ts = ts[ts > start_time]
            trimmed_log = log[ts > start_time]

            initial_val = trimmed_log[0]
            trigger_val = row[2 + i]
            if initial_val > trigger_val:
                t = np.nanmin(trimmed_ts[trimmed_log < trigger_val])
                cur_min_t = t if t < cur_min_t else cur_min_t

        return cur_min_t

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

filepath = r"C:\Users\jim-b\Documents\University\IIB\Project\Tests\230904 Pump Calibration\stepperPreciseStepUpDown10s5ms.csv"
# filepath = r"C:\Users\jim-b\Documents\University\IIB\Project\Tests\230901 Pump Calibration\stepperStepUpDown10s.csv"

length_per_speed = 10
start_speed = 0


def main():
    pump_times, pump_speeds = generate_pump_values()
    df = pd.read_csv(filepath, skiprows=15)
    df = df.replace(',', '', regex=True)

    ks = df.keys().to_numpy()
    raw_t = df[ks[1]].to_numpy()
    raw_flow = df[ks[2]].to_numpy()

    start_time = get_start_time(raw_t, raw_flow)

    print(type(start_time))

    raw_t = raw_t.astype(np.float32)

    for t in raw_t:
        if type(t) != np.float32:
            print(t, type(t))

    raw_t -= start_time
    ts = raw_t[raw_t > 0]
    flows = raw_flow[raw_t > 0]

    mean_flows = []

    pump_speeds_stepped = np.zeros_like(flows)

    for i in range(len(pump_speeds)):
        mean_flows.append(np.mean(flows[np.logical_and(
            ts > pump_times[i] + 2, ts < pump_times[i] + length_per_speed - 1)]))
        pump_speeds_stepped[np.logical_and(
            ts > pump_times[i], ts < pump_times[i] + length_per_speed)] = pump_speeds[i]

    plt.plot(pump_speeds[:256], mean_flows[:256])
    plt.plot(pump_speeds[256:], mean_flows[256:])
    plt.show()

    plt.plot(ts, flows)
    plt.plot(ts, pump_speeds_stepped)
    plt.show()


def get_start_time(raw_t, raw_flow):
    return 9038.4
    # return 171.4
    # return 259.2
    # return 1193.9


def generate_pump_values():
    pump_speeds = []
    pump_times = []
    cur_time = 0
    for i in range(start_speed, 256):
        pump_speeds.append(i)
        cur_time += (i * 10)/1000
        pump_times.append(cur_time)
        cur_time += length_per_speed

    for i in range(255, start_speed - 1, -1):
        pump_speeds.append(i)
        cur_time += (i * 10)/1000
        pump_times.append(cur_time)
        cur_time += length_per_speed

    return np.array(pump_times), np.array(pump_speeds)


if __name__ == "__main__":
    main()

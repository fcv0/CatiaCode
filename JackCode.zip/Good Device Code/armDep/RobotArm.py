import os, numpy, time
import DobotDllType as dType

class _Main:
    message = numpy.zeros((30, 1), dtype=numpy.uint8)
    def __init__(self) -> None:
        pass

class FRecord:
    HOMED = False
    colPos = 0
    colStartCoords = [[180, 0, 50, 0], [180, -20, 50, 0], [180, -40, 50, 0], [180, -60, 50, 0]] # x, y, z, r; let r = 0
    injectCoords = [[180, 0, -50, 0], [180, -20, -50, 0], [180, -40, -50, 0], [180, -60, -50, 0]]
    wasteCoords = [200, 80, 140, 0]
    MotorIDX, PinchIDX, wellIDX, colOffset = [6, 5], [0, 1, 2], 0, 0 # change motorIDX
    PumpingActive, MoveState, InjectState, WasteState, PumpDone = False, True, False, False, False
    INITSTATE, MoveInject, InjectWaste, MoveDone, FIRST = True, False, False, False, True
    wellComplete = False
    def __init__(self) -> None:
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        self.api, self.state = self.connectTo()
        if (self.state == dType.DobotConnect.DobotConnect_NoError):
            dType.RestartMagicBox(self.api)
            dType.ClearAllAlarmsState(self.api)
            dType.SetQueuedCmdClear(self.api)
            ## apply settings to instance
            if not self.HOMED:
                self.HOMED = self._HomeInstance
            while True:
                self.ArmMovement()
                #dType.GetQueuedCmdMotionFinish(self.api)
            # except KeyboardInterrupt:
            #     dType.ClearAllAlarmsState(self.api)
            #     dType.SetQueuedCmdForceStopExec(self.api)
            #     dType.SetQueuedCmdClear(self.api)
            #     dType.SetQueuedCmdStopExec(self.api)
            #     dType.DisconnectDobot(self.api)

    @staticmethod
    def connectTo():
        CON_STR = {dType.DobotConnect.DobotConnect_NoError:  "DobotConnect_NoError", dType.DobotConnect.DobotConnect_NotFound: "DobotConnect_NotFound", dType.DobotConnect.DobotConnect_Occupied: "DobotConnect_Occupied"}
        api = dType.load()
        state = dType.ConnectDobot(api, "", 115200)[0]
        print("Connect status: ", CON_STR[state])
        return api, state

    @property
    def _HomeInstance(self, ) -> None:
        # Single homing called vs 
        dType.GetQueuedCmdMotionFinish(self.api)
        dType.SetHOMEParams(self.api, x=200, y=200, z=200, r=0, isQueued = 1) # r was 200 idk if thats correct ? 
        dType.SetPTPJointParams(self.api, 200, 200, 200, 200, 200, 200, 200, 200, isQueued = 1)
        dType.SetPTPCommonParams(self.api, 100, 100,isQueued = 1)
        ls = dType.SetHOMECmd(self.api, temp=0, isQueued = 1)[0]
        # while ls > dType.GetQueuedCmdCurrentIndex(self.api)[0]:
        #     dType.dSleep(100)
        # print(dType.GetArmSpeedRatio(self.api))
        return True

    def _strelTube(self, ) -> None:
        if self.pumpFossilSample:
            print('Bleaching')
            time.sleep(2)
            print('Water wash')
            time.sleep(4)
            print('Complete strel')
            self.pumpFossilSample = False
            
    def ArmReady(self, ) -> bool:
        if self.wellComplete:
            return True
        return False
    
    def testPumping(self, ):
        if self.pumpFossilSample:
            print('Pumping... ')
            time.sleep(2)
            self.pumpFossilSample = False
            print('Complete... ')
    
    def checkPumpState(self, ) -> bool:
        if self.PumpingActive and not self.MoveState:
            return True
        return False
    
    def checkMoveState(self, ) -> bool:
        if not self.PumpingActive and self.MoveState:
            return True
        return False
    
    def TriggerRecord(self, ) -> None:
        self.MoveState = True
        self.INITSTATE = True

    def ArmMovement(self, ) -> None:
        self.wellComplete = False
        if (self.state == dType.DobotConnect.DobotConnect_NoError):
            if self.INITSTATE and self.checkMoveState(): # MoveState = true -> INITSTATE = true
                if self.FIRST:
                    dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=(self.colStartCoords[self.colPos][0]+(self.wellIDX*20)), y=self.colStartCoords[self.colPos][1], z=self.colStartCoords[self.colPos][2], rHead=self.colStartCoords[self.colPos][3], isQueued=1)
                    dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=(self.injectCoords[self.colPos][0]+(self.wellIDX*20)), y=self.injectCoords[self.colPos][1], z=self.injectCoords[self.colPos][2], rHead=self.injectCoords[self.colPos][3], isQueued=1)
                    self.FIRST = False
                else:
                    #dType.SetQueuedCmdStopExec(self.api)
                    pose = dType.GetPose(self.api)[:4] # x, y, z, r
                    #print(pose, 'Ender vector pose relative to home. ')
                    if (self.colStartCoords[self.colPos][0]+(self.wellIDX*20)) == round(pose[0]) and (self.colStartCoords[self.colPos][1]) == round(pose[1]) and self.colStartCoords[self.colPos][2] == round(pose[2]) and self.colStartCoords[self.colPos][3] == round(pose[3]):
                        self.MoveState = False
                        self.INITSTATE = False
                        self.FIRST = True
                        self.InjectState = True
                        self.PumpingActive = True
            elif self.checkPumpState() and not self.checkMoveState() and self.InjectState:
                self.activePump = self.MotorIDX[0]
                self.pumpTime = 5000 # ms
                if self.FIRST:
                    self.pumpFossilSample = True
                    self.FIRST = False
                    self.testPumping()
                if self.pumpFossilSample == False:
                    self.InjectState = False
                    self.PumpingActive = False
                    self.MoveState = True
                    self.FIRST = True
                    self.WasteState = True
            elif not self.InjectState and not self.checkPumpState() and self.checkMoveState() and self.WasteState:
                if self.FIRST:
                    dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=(self.colStartCoords[self.colPos][0]+(self.wellIDX*20)), y=self.colStartCoords[self.colPos][1], z=self.colStartCoords[self.colPos][2], rHead=self.colStartCoords[self.colPos][3], isQueued=1)
                    dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.wasteCoords[0], y=self.wasteCoords[1], z=self.wasteCoords[2], rHead=self.wasteCoords[3], isQueued=1)
                    dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.wasteCoords[0], y=self.wasteCoords[1], z=(self.wasteCoords[2]-60), rHead=self.wasteCoords[3], isQueued=1)
                    self.FIRST = False
                else:
                    pose = dType.GetPose(self.api)[:4]
                    #print(pose, 'Ender vector pose relative to home. ')
                    if self.wasteCoords[0] == int(pose[0]) and self.wasteCoords[1] == int(pose[1]) and (self.wasteCoords[2]-60) == int(pose[2]) and self.wasteCoords[3] == int(pose[3]):
                        self.MoveState = False
                        self.FIRST = True
                        self.PumpingActive = True
                        self.InjectWaste = True
                        self.WasteState = False
            elif self.InjectWaste and self.checkPumpState() and not self.checkMoveState():
                if self.FIRST:
                    self.pumpFossilSample = True
                    self.motorIDX = self.MotorIDX[1]
                    self.pumpTime = 15000 #ms
                    self._strelTube()
                    self.FIRST = False
                if self.pumpFossilSample == False:
                    self.InjectWaste = False
                    self.PumpingActive = False
                    self.MoveState = True
                    self.FIRST = True
                    self.MoveDone = True
            elif not self.checkPumpState() and self.checkMoveState() and self.MoveDone:
                dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.wasteCoords[0], y=self.wasteCoords[1], z=self.wasteCoords[2], rHead=self.wasteCoords[3], isQueued=1)
                self.wellComplete = True
                self.INITSTATE = True
            if self.wellComplete:
                self.wellIDX += 1
                print('Well IDX', self.wellIDX)
                if ((self.wellIDX / 6) == 1) or ((self.wellIDX / 6) == 2) or ((self.wellIDX / 6) == 3):
                    self.colPos += 1
                    self.colOffset += 1
                    self.wellIDX = 0
                # tmp code
                if self.colPos == 3:
                    self.colPos = 0

        

    # def main(self, ) -> None:
    #     # time.sleep is just better...
    #     dType.GetQueuedCmdMotionFinish(self.api)
    #     # idk if commands in here should be queued into the buffer.
    #     _Main.message[29] = 1
    #     if (self.state == dType.DobotConnect.DobotConnect_NoError) and (_Main.message[29] > 0): # _Main.message[29] = well position -> 1, 2, 3 ... 4 going up then across once 6 is achieved. Best to add a timer to this function, I.E sample rate = 3600 seconds -> 1 hour, do action.
    #         for i in range(0, 23):
    #             # Each well needs three actions -> init pos, z=+50 -> probe pos, z=-50 -> reset pos -> z=+50 then over waste. E.G
    #             dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.colStartCoords[self.colPos][0], y=self.colStartCoords[self.colPos][1], z=self.colStartCoords[self.colPos][2], rHead=self.colStartCoords[self.colPos][3], isQueued=1)
    #             # Then we inject and pump the sample.
    #             dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.injectCoords[self.colPos][0], y=self.injectCoords[self.colPos][1], z=self.injectCoords[self.colPos][2], rHead=self.injectCoords[self.colPos][3], isQueued=1)
    #             self._pumpSample()
    #             # Then we reset the arm to standard pos.
    #             dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.colStartCoords[self.colPos][0], y=self.colStartCoords[self.colPos][1], z=self.colStartCoords[self.colPos][2], rHead=self.colStartCoords[self.colPos][3], isQueued=1)
    #             # Then we hover over waste pos.
    #             dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.wasteCoords[0], y=self.wasteCoords[1], z=self.wasteCoords[2], rHead=self.wasteCoords[3], isQueued=1)
    #             dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.wasteCoords[0], y=self.wasteCoords[1], z=(self.wasteCoords[2]-60), rHead=self.wasteCoords[3], isQueued=1)
    #             self._strelTube()
    #             ls = dType.SetPTPCmd(self.api, dType.PTPMode.PTPMOVLXYZMode, x=self.wasteCoords[0], y=self.wasteCoords[1], z=self.wasteCoords[2], rHead=self.wasteCoords[3], isQueued=1)[0]
    #             # Then reset pos.

    #             self.colStartCoords[self.colPos][0] += 20
    #             self.injectCoords[self.colPos][0] += 20
    #             if i  == 5 or i == 11 or i == 17:
    #                 self.colPos += 1
    #             # if self.colStartCoords[self.colPos][0] >= 300:
    #             #     self.colPos += 1
    #         while ls > dType.GetQueuedCmdCurrentIndex(self.api)[0]:
    #             dType.dSleep(100)
            
FRecord()
import os, numpy, time
import armDep.DobotDllType as robot

os.chdir(os.path.abspath(os.path.dirname(__file__)))

class arm:
    armConnected = False
    connectState = {
        robot.DobotConnect.DobotConnect_NoError:  "DobotConnect_NoError",
        robot.DobotConnect.DobotConnect_NotFound: "DobotConnect_NotFound",
        robot.DobotConnect.DobotConnect_Occupied: "DobotConnect_Occupied"}
    wastePosition = []
    startingPosition = []
    def __init__(self) -> None:
        os.chdir(f"{os.getcwd()}\\armDep")
        while not self.armConnected:
            self.robotAPI = robot.load()
            state = robot.ConnectDobot(self.robotAPI, "COM5", 115200)[0]
            print("Connection status: ", self.connectState[state])
            self.armConnected = True
            #robot.SetQueuedCmdForceStopExec(self.robotAPI)
            robot.ClearAllAlarmsState(self.robotAPI)
            time.sleep(2)

        if (state == robot.DobotConnect.DobotConnect_NoError):
            self.homed = self.armHoming
            
        if self.homed:
            self.armMovement()
        #self.armComplete
    
    @property
    def armHoming(self, ) -> bool:
        complete = False
        robot.SetQueuedCmdClear(self.robotAPI)
        robot.SetHOMEParams(self.robotAPI, 160, 0, 80, -6)
        robot.SetHOMECmdEx(self.robotAPI, temp=0)
        complete = True
        robot.SetEndEffectorTypeEx(self.robotAPI, 0)
        robot.SetEndEffectorParamsEx(self.robotAPI, xBias=1.0, yBias=1.0, zBias=1.0)
        return complete
    
    @property
    def armComplete(self, ) -> None:
        robot.ClearAllAlarmsState(self.robotAPI)
        robot.SetQueuedCmdForceStopExec(self.robotAPI)
        robot.DisconnectDobot(self.robotAPI)
    
    def armMovement(self, ) -> None:
        robot.SetQueuedCmdClear(self.robotAPI)
        i, j = 0, 0
        pos = [214.7, 34.1, -95.9, 2.76]
        try:
            while True: # x = 140 to 250, y = -156 to 156, z = -97 to 161
                robot.ClearAllAlarmsState(self.robotAPI)
                print(robot.GetPose(self.robotAPI)[:4])
                r = robot.GetPoseEx(self.robotAPI, 4)
                robot.SetPTPCmdEx(self.robotAPI, robot.PTPMode.PTPMOVLXYZMode, x=pos[0], y=pos[1], z=pos[2], rHead=r)


                #robot.SetPTPCmdEx(self.robotAPI, robot.PTPMode.PTPMOVJXYZMode, x=195, y=0, z=10, rHead=r)

        except KeyboardInterrupt:
            self.armComplete
            print("Movement complete. ")
            exit()

arm() # [142.85910034179688, 39.763343811035156, -93.19221496582031, 9.167612075805664]
#define TCAADDR 0x70


#define Cin1 24
#define Cin2 25
#define CM 10
#define heaterPin 28
#define fanPin 2

#define wastePin 3
#define freshPin 4
#define freshDirPin 32
#define wasteDirPin 33

#define MMmotor 6
#define motherMachineOnOff 34

#define PCB1 0
#define PCB2 1
#define PCB3 2
#define TempSens 3
#define diode1_addr 0x44
#define diode2_addr 0x45
#define diode3_addr 0x47
#define result_reg 0x00
#define config_reg 0x01
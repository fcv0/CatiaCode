import os, numpy, pandas, math
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

os.chdir(os.path.abspath(os.path.dirname(__file__)))

data = pandas.read_csv("dataLog_23-2-2024_13-7-34.csv")

time = data.iloc[:, 11].to_numpy()

main = data.iloc[:, 2].to_numpy()

basis = data.iloc[:, 3].to_numpy()

coeffs = data.iloc[:, 9].to_numpy()

temp = data.iloc[:, 7].to_numpy()

coeff_900 = numpy.mean(coeffs[:900])

coeff_var = numpy.var(coeffs[:900])

print(coeff_900, coeff_var,  'Coefficient mean, variance')

OD = []

for i in range(len(time)):
    od = -9.2*math.log10(main[i]/(basis[i]*coeff_900))
    OD.append(od)

sgFiltered = savgol_filter(OD, 50, 3)

meanOD_900 = numpy.mean(OD[:900])
varianceOD_900 = numpy.var(OD[:900])

fmeanOD_900 = numpy.mean(sgFiltered[:900])
fvarOD_900 = numpy.var(sgFiltered[:900])

print(meanOD_900, varianceOD_900 , 'OD 900 mean and variance. ')
print(fmeanOD_900, fvarOD_900, 'Filtered OD and variance 900')

lbound = 24000
boundDiff = 1200
ubound = lbound+boundDiff

gradient = (sgFiltered[ubound] - sgFiltered[lbound]) / boundDiff
print(gradient)

plt.plot(time[:900], sgFiltered[:900], 'g-', alpha=0.5), plt.plot(time[:900], OD[:900], 'r-', alpha=0.5), plt.xlabel('Time (s)'), plt.ylabel('OD'), plt.title('OD vs Time full'), plt.legend(["Red = standard", "Green = Filtered"]), plt.show()

plt.plot(time, OD, 'r-', alpha=0.5), plt.plot(time, sgFiltered, 'g-', alpha=0.5), plt.xlabel('Time (s)'), plt.ylabel('OD'), plt.title('OD vs Time full (sgFiltered)'), plt.legend(["Red = standard", "Green = filtered (sg)"]), plt.show()
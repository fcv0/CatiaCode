import sys, time, numpy, os, serial, threading, struct, pandas, math
import matplotlib.pyplot as plt
from serial.tools import list_ports
from PyQt6.QtWidgets import QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QLineEdit, QPushButton, QLabel, QGraphicsEllipseItem, QGraphicsView, QGraphicsScene
from PyQt6.QtCore import QTimer, QRectF
from PyQt6.QtGui import QBrush, QColor
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


class _Variables:
    '''
    You can edit this class, for different starting values/changes, kinda depends on system to system on how their wired tbh...
    sensorFreq currently is a single data points update time, bufferFreq is a single update point 1 = 1 second -> if sensorFreq = 10 therefore, buffer array has 10 values...
    expTime = experiment time...
    calcCoeffTimer is also another variable that can lead to differing results, be careful putting it +1 hour into an exp. 15 minutes (900 s) works well... 
    '''
    armPresent, armActive, valveState = True, False, [[0, 0, 0], [0, 0, 1], [0, 1, 0], [1, 0, 0]]
    pumpTime = 1 # Need to change this based on the volume acquired from 255 of the stepper motor -> Is it enough for sampling? Calibration exp.
    tStep = 8
    stepper1Speed, stepper1Dir, stepper2Speed, stepper2Dir = 0, 0, 0, 0
    cSpeed, cDir, fanSpeed = 230, 0, 50
    photodiode_1_main, photodiode_2_main, photodiode_3_main = [], [], []
    photodiode_1_basis, photodiode_2_basis, photodiode_3_basis = [], [], []
    Coeff_1, Coeff_2, Coeff_3 = [], [], []
    OD1, OD2, OD3 = [], [], []
    hardwareTime, ambientTemp, objTemp = [], [], []
    relayState = []
    targetTemp, targetOD = 37.0, 2.0
    motherMachineSpeed = 0
    pyMessage = numpy.zeros((20, 1), dtype=numpy.uint8) # You can change the length of this to include more bytes, but you need to do the same change on the arduino side of things.
    runTime, sensorFreq, expTime, bufferFreq = None, 10, 700000, 1 # sensorFreq is the capture rate of the sensors, minima = 0.801, keep as int please... Also exp time should be set in the config file (once present).
    if type(sensorFreq) != int: sensorFreq = int(sensorFreq)
    commsTurn = True # Should always be true as an init state.
    _Device, deviceStatus, startDHandle = None, 0, False # This should point to arduino.
    avgCoefficient1, avgCoefficient2, avgCoefficient3 = None, None, None
    calibrationCoeff, calcCoeffTimer = 9.2, 900
    # For the addition of the fossil recorder (dobot) code.
    fossilRecord = False # Should be togglable in GUI or changable in config (config doesnt exist lol...)
    sterlActive = False
    sterlDevice = None

    def __init__(self, ) -> None:
        targOD, targTemp = Tools.float2bytes(self.targetOD), Tools.float2bytes(self.targetTemp)
        self.pyMessage[0] = self.deviceStatus
        self.pyMessage[1] = self.cDir
        self.pyMessage[2] = self.cSpeed

        self.pyMessage[7] = self.fanSpeed


        self.pyMessage[10] = targOD[0]
        self.pyMessage[11] = targOD[1]
        self.pyMessage[12] = targOD[2]
        self.pyMessage[13] = targOD[3]

        self.pyMessage[14] = targTemp[0]
        self.pyMessage[15] = targTemp[1]
        self.pyMessage[16] = targTemp[2]
        self.pyMessage[17] = targTemp[3]
        self.pyMessage[18] = 0


class Tools(_Variables):
    '''
    Handles most of the backend work... Calculations and Communication to the Master Device.
    '''
    initFind = True
    notFound = True
    retry = 3 # seconds.
    def __init__(self) -> None:
        super().__init__()
   
    @staticmethod
    def find_port(PP=None):
        # Automatically find arduino com port, however break if mutliple are connected.
        for port in list_ports.comports(include_links=False):
            if PP != None:
                if port.device == PP:
                    continue
            if 'arduino' in port.description.lower(): # We could use vendor ID also but this should suffice.
                print(f'Found port: {port.device}')
                PORT = port.device
                break
            else:   continue
        print('Device information: ', PORT)
        PORT = serial.Serial(port=PORT, baudrate=9600, timeout=.1)
        PORT.flushInput(), PORT.flushOutput()
        print(f'Connecting to {PORT.name}')
        return PORT

    @staticmethod
    def startSeq():
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        os.chdir(f'{os.getcwd()}/logs/')
        while Tools.notFound:
            #os.system('cls')
            try:
                _Variables._Device = Tools.find_port()#serial.Serial(port="COM10", timeout=.1, baudrate=9600)
            except: print('Could not find micro-controller. ')
            if _Variables._Device != None:
                Tools.notFound = False
                break
            else: time.sleep(Tools.retry)
            time.sleep(1)
    
    @staticmethod
    def clearArrays():
        _Variables.photodiode_1_basis, _Variables.photodiode_2_basis, _Variables.photodiode_3_basis = [], [], []
        _Variables.photodiode_1_main, _Variables.photodiode_2_main, _Variables.photodiode_3_main = [], [], []
        _Variables.ambientTemp, _Variables.objTemp = [], []
        _Variables.OD1, _Variables.OD2, _Variables.OD3 = [], [], []
        _Variables.Coeff_1, _Variables.Coeff_2, _Variables.Coeff_3 = [], [], []

    @staticmethod
    def createFolder() -> None:
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        if os.path.isdir('logs/') == False:
            os.mkdir('logs/')
        else:
            pass
   
    @staticmethod
    def dataSave(*arrays) -> None:
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        os.chdir(f"{os.getcwd()}\\logs")
        runName = f'dataLog_{time.localtime()[2]}-{time.localtime()[1]}-{time.localtime()[0]}_{time.localtime()[3]}-{time.localtime()[4]}-{time.localtime()[5]}.csv'
        df = pandas.DataFrame(arrays)
        df = df.T
        df.to_csv(runName, header=False, index=False)
   
    @staticmethod
    def float2bytes(data) -> bytes:
        return list(struct.pack('!f', data))

    @staticmethod
    def bytes2float(data) -> float:
        return struct.unpack('f', data[::-1])[0]
   
    @staticmethod
    def bytes2int(data) -> int:
        # this isn't really needed to be honest.
        return int.from_bytes(data, 'little')

    @property
    def set_defaults(self, ) -> None:
        targOD, targTemp = self.float2bytes(_Variables.targetOD), self.float2bytes(_Variables.targetTemp)

        _Variables.pyMessage[0] = _Variables.deviceStatus
        _Variables.pyMessage[1] = _Variables.cSpeed
        _Variables.pyMessage[2] = _Variables.cDir
        ## Leave 3 to 6 for turbidostat motors -  (and dir).

        _Variables.pyMessage[7] = _Variables.fanSpeed
        ## Leave 8 and 9 for Mother Machine control

        _Variables.pyMessage[10] = targOD[0]
        _Variables.pyMessage[11] = targOD[1]
        _Variables.pyMessage[12] = targOD[2]
        _Variables.pyMessage[13] = targOD[3]

        _Variables.pyMessage[14] = targTemp[0]
        _Variables.pyMessage[15] = targTemp[1]
        _Variables.pyMessage[16] = targTemp[2]
        _Variables.pyMessage[17] = targTemp[3]

        _Variables.pyMessage[18] = 0
       
        ## Can increase the array size for additional components.
   
    @staticmethod
    def checkMotorValues(Updated_Variable): 
        '''
        This should be stable for all motors. 
        Checks if the text within an entry field can be sent
        '''
        Dir = 0
        if len(Updated_Variable) == 0:
            Updated_Variable = 0
        elif '-' in Updated_Variable and len(Updated_Variable) == 1:
            Updated_Variable = '-0'
        else:
            if '-' in Updated_Variable:
                Updated_Variable = Updated_Variable[1:]
                Dir = 1
                if int(Updated_Variable) is None:
                    Updated_Variable = 0
            elif int(Updated_Variable) >= 255:
                Updated_Variable = 255
        return Dir, Updated_Variable

    @property
    def finalCoefficient(self, ) -> None:
        ## command action -> if abs(self.startTime - time.time()) >= 900:
        return numpy.mean(_Variables.Coeff_1), numpy.mean(_Variables.Coeff_2), numpy.mean(_Variables.Coeff_3)
   
    @staticmethod
    def calculateCoeff() -> None:
        # We can see the error in the coefficient across time later, compared to the 15 minutes coefficient calculated.
        #coeff_1, coeff_2, coeff_3 = (_Variables.photodiode_1_main/_Variables.photodiode_1_basis), (_Variables.photodiode_2_main/_Variables.photodiode_2_basis), (_Variables.photodiode_3_main/_Variables.photodiode_3_basis)
        #_Variables.Coeff_1.append(coeff_1), _Variables.Coeff_2.append(coeff_2), _Variables.Coeff_3.append(coeff_3)
        if len(_Variables.photodiode_2_main) > 0:
            coeff_2 = (_Variables.photodiode_2_main[-1]/_Variables.photodiode_2_basis[-1])
            _Variables.Coeff_2.append(coeff_2)
   
    @staticmethod
    def calculateOD() -> None:
        '''
        For OD calculation. Need to work for all diodes, ill do that later when its required... 
        '''
        if len(_Variables.photodiode_2_main) > 0:
            if (_Variables.hardwareTime[-1] >= _Variables.calcCoeffTimer) and _Variables.avgCoefficient2 != None:
                _Variables.avgCoefficient1, _Variables.avgCoefficient2, _Variables.avgCoefficient3 = Tools.finalCoefficient
                multi = _Variables.avgCoefficient2
            else: multi = numpy.mean(_Variables.Coeff_2) # numpy.mean(_Variables.Coeff2[0])
                #od1 = (-_Variables.calibrationCoeff*math.log10(_Variables.photodiode_1_main[-1]/(_Variables.photodiode_1_basis[-1]*_Variables.avgCoefficient1)))
            od2 = round((_Variables.calibrationCoeff*math.log10((_Variables.photodiode_2_basis[-1]*multi)/(_Variables.photodiode_2_main[-1]))), 3)
                #od3 = (-_Variables.calibrationCoeff*math.log10(_Variables.photodiode_3_main[-1]/(_Variables.photodiode_3_basis[-1]*_Variables.avgCoefficient3)))
                #_Variables.OD1.append(od1), _Variables.OD2.append(od2), _Variables.OD3.append(od3)
            _Variables.OD2.append(od2)

    @staticmethod
    def dataHandle() -> None:
        '''
        Communication function -> turn based with arduino, waits for X bytes then send Y bytes bouncing as fast as possible -> 56 bytes ~ 18kB s^-1 = 321 Hz at 9600 baud
        '''
        # counts
        sC, sD, tH, bC = 1, 1, 1, 1
        print("Starting communication... ")
        main1Buffer, main2Buffer, main3Buffer = [], [], []
        basis1Buffer, basis2Buffer, basis3Buffer = [], [], []
        while _Variables.startDHandle:
            if _Variables.commsTurn == False:
                if _Variables._Device.in_waiting >= 36:
                    os.system('cls')
                    incomingBytes = _Variables._Device.read(36)
                    print(f'Ambient temperature: {Tools.bytes2float(incomingBytes[24:28])} | Object temperature: {Tools.bytes2float(incomingBytes[28:32])} | System time: {(Tools.bytes2float(incomingBytes[32:36])/1000)}')
                    print(Tools.bytes2float(incomingBytes[0:4]), Tools.bytes2float(incomingBytes[4:8]), Tools.bytes2float(incomingBytes[8:12]), Tools.bytes2float(incomingBytes[12:16]), Tools.bytes2float(incomingBytes[16:20]), Tools.bytes2float(incomingBytes[20:24]))
                    # _Variables.photodiode_1_main.append(Tools.bytes2float(incomingBytes[:4])), _Variables.photodiode_2_main.append(Tools.bytes2float(incomingBytes[4:8])), _Variables.photodiode_3_main.append(Tools.bytes2float(incomingBytes[8:12]))
                    # _Variables.photodiode_1_basis.append(Tools.bytes2float(incomingBytes[12:16])), _Variables.photodiode_2_basis.append(Tools.bytes2float(incomingBytes[16:20])), _Variables.photodiode_3_basis.append(Tools.bytes2float(incomingBytes[20:24]))
                    # _Variables.ambientTemp.append(Tools.bytes2float(incomingBytes[24:28])), _Variables.objTemp.append(Tools.bytes2float(incomingBytes[28:32])), _Variables.hardwareTime.append((Tools.bytes2float(incomingBytes[32:36])/1000))
                    # Tools.calculateCoeff(), Tools.calculateOD()
                    currTime = Tools.bytes2float(incomingBytes[32:36])/1000
                    print(currTime, type(currTime))
                    print(numpy.mean(_Variables.Coeff_2))
                    if currTime >= _Variables.expTime:
                        _Variables.startDHandle = False
                    if currTime // _Variables.bufferFreq == bC:
                        # Data buffer for photodiode values 
                        main1Buffer.append(Tools.bytes2float(incomingBytes[:4])), main2Buffer.append(Tools.bytes2float(incomingBytes[4:8])), main3Buffer.append(Tools.bytes2float(incomingBytes[8:12]))
                        basis1Buffer.append(Tools.bytes2float(incomingBytes[12:16])), basis2Buffer.append(Tools.bytes2float(incomingBytes[16:20])), basis3Buffer.append(Tools.bytes2float(incomingBytes[20:24]))
                        bC +=1
                    if currTime // _Variables.sensorFreq == sC: ## I could do it here but that kinda fucks with the sensor frequency, maybe its a possiblity to grab both to show the difference between sensing between activations and not; -> more arrays = happy happy.
                        # This should work fine.
                        sC += 1
                        print('Plotting arrays')
                        _Variables.photodiode_1_main.append(numpy.mean(main1Buffer)), _Variables.photodiode_2_main.append(numpy.mean(main2Buffer)), _Variables.photodiode_3_main.append(numpy.mean(main3Buffer))
                        _Variables.photodiode_1_basis.append(numpy.mean(basis1Buffer)), _Variables.photodiode_2_basis.append(numpy.mean(basis2Buffer)), _Variables.photodiode_3_basis.append(numpy.mean(basis3Buffer))
                        # _Variables.photodiode_1_main.append(Tools.bytes2float(incomingBytes[:4])), _Variables.photodiode_2_main.append(Tools.bytes2float(incomingBytes[4:8])), _Variables.photodiode_3_main.append(Tools.bytes2float(incomingBytes[8:12]))
                        # _Variables.photodiode_1_basis.append(Tools.bytes2float(incomingBytes[12:16])), _Variables.photodiode_2_basis.append(Tools.bytes2float(incomingBytes[16:20])), _Variables.photodiode_3_basis.append(Tools.bytes2float(incomingBytes[20:24]))
                        _Variables.ambientTemp.append(Tools.bytes2float(incomingBytes[24:28])), _Variables.objTemp.append(Tools.bytes2float(incomingBytes[28:32])), _Variables.hardwareTime.append((Tools.bytes2float(incomingBytes[32:36])/1000))
                        Tools.calculateCoeff(), Tools.calculateOD()
                        main1Buffer, main2Buffer, main3Buffer, basis1Buffer, basis2Buffer, basis3Buffer = [], [], [], [], [], []
                    if currTime // 2000 == sD:
                        # save data every 2k seconds
                        sD += 1
                        Tools.createFolder() # If folder is present it  points towards folder.
                        Tools.dataSave(_Variables.photodiode_1_main, _Variables.photodiode_1_basis, _Variables.photodiode_2_main, _Variables.photodiode_2_basis,
                        _Variables.photodiode_3_main, _Variables.photodiode_3_basis, _Variables.OD1, _Variables.OD2, _Variables.OD3, _Variables.ambientTemp, _Variables.objTemp, _Variables.Coeff_1, _Variables.Coeff_2, _Variables.Coeff_3, _Variables.hardwareTime)
                    if currTime // 5 == tH:
                        # allow heat mat to change state every 5 seconds
                        tH += 1
                        _Variables.pyMessage[18] = 1
                        # 1 meaning state change allowed.
                    else: _Variables.pyMessage[18] = 0
                    if currTime // _Variables.expTime == 1:
                        _Variables.pyMessage[18] = 1
                        _Variables.targetTemp = 0
                    _Variables.commsTurn = True
            else:
                # else send the pyMessage to arduino
                _Variables._Device.write(bytes(_Variables.pyMessage))
                _Variables.commsTurn = False
        if _Variables.startDHandle == False:
            # If the handle doesn't exist send an empty message to stop electronics (need to fix the relay cus 1 is allowed to switch state, now it doesnt stop...)
            _Variables._Device.write(bytes(numpy.zeros((20, 1), dtype=numpy.uint8)))
            roboticArm.armComplete

class App(QMainWindow, Tools):
    startState = True
    initialStart = True
    circs = []
    def __init__(self):
        super().__init__()
        self.title = 'aPEX Grow'
        self.left = 50
        self.top = 50
        self.width = 1600
        self.height = 1000
        self.initUI()
   
    def initUI(self):
        # Setupd
        Tools.set_defaults
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        tab_widget = QTabWidget()
        self.setCentralWidget(tab_widget)

        # Control tab
        controlTab = QWidget()
        controlTab_layout = QVBoxLayout()
        controlTab.setLayout(controlTab_layout)
        tab_widget.addTab(controlTab, 'Device Control')
        
        
        self.connectStart = QPushButton('Connect and Start')
        self.saveData = QPushButton('Manual save')
        
        self.cSpeedEdit = QLineEdit()
        self.fanSpeedEdit = QLineEdit()
        self.targTempEdit = QLineEdit()
        self.targODEdit = QLineEdit()
        self.m1SpeedEdit = QLineEdit()
        self.m2SpeedEdit = QLineEdit()
        self.cSpeedEdit.setText(f'{_Variables.cSpeed} cycle motor speed')
        self.fanSpeedEdit.setText(f'{_Variables.fanSpeed} fan speed')
        self.targTempEdit.setText(f'{_Variables.targetTemp} target Temp')
        self.targODEdit.setText(f'{_Variables.targetOD} target OD')
        self.m1SpeedEdit.setText(f'{_Variables.stepper1Speed} stepper 1')
        self.m2SpeedEdit.setText(f'{-_Variables.stepper2Speed} stepper 2')
        self.connectStart.pressed.connect(lambda: self.startRun())
        self.fanSpeedEdit.textChanged.connect(self.updateFS)
        self.cSpeedEdit.textChanged.connect(self.updateCM)
        self.targTempEdit.textChanged.connect(self.updateTargTemp)
        self.targODEdit.textChanged.connect(self.updateTargOD)
        self.saveData.pressed.connect(self.qkSave)
        self.m1SpeedEdit.textChanged.connect(self.stepper1Change)
        self.m1SpeedEdit.textChanged.connect(self.stepper2Change)
        
        controlTab_layout.addWidget(self.cSpeedEdit)
        controlTab_layout.addWidget(self.fanSpeedEdit)
        controlTab_layout.addWidget(self.targTempEdit)
        controlTab_layout.addWidget(self.targODEdit)
        controlTab_layout.addWidget(self.saveData)
        self.temperature = PlotCanvas()
        controlTab_layout.addWidget(self.temperature)
        controlTab_layout.addWidget(self.connectStart)
        self.motherMachineSpeed = QLineEdit()
        controlTab_layout.addWidget(self.m1SpeedEdit)
        controlTab_layout.addWidget(self.m2SpeedEdit)
        controlTab_layout.addWidget(self.motherMachineSpeed)
        self.motherMachineSpeed.textChanged.connect(self.updateMM)
        self.motherMachineSpeed.setText(f"{_Variables.motherMachineSpeed} MM motor speed")

        # Graphing tab

        graphingTab = QWidget()
        graphingTab_layout = QVBoxLayout()
        self.resetArrays = QPushButton("Reset data")
        graphingTab_layout.addWidget(self.resetArrays)
        self.resetArrays.pressed.connect(self.resetData)
        graphingTab.setLayout(graphingTab_layout)
        tab_widget.addTab(graphingTab, 'Graphing Tab')
        self.rawReadings = PlotCanvas()
        graphingTab_layout.addWidget(self.rawReadings)
        self.opticalDensity = PlotCanvas()
        graphingTab_layout.addWidget(self.opticalDensity)
        
        # Steriliser tab
        streliserTab = QWidget()
        streliserTab_layout = QVBoxLayout()
        streliserTab.setLayout(streliserTab_layout)
        tab_widget.addTab(streliserTab, 'Sterlisation')
        self.noticeSterl = QLabel("Ensure that the inlet and outlet are connected to the correct tubing and the bottles connected are suitable for a sequence.")
        self.startSterl = QPushButton("Start sterlisation")
        streliserTab_layout.addWidget(self.noticeSterl)
        streliserTab_layout.addWidget(self.startSterl)
        self.startSterl.pressed.connect(self.sterlSeq)
        
        # Fossil record tab 
        fossilTab = QWidget()
        fossilTab_layout = QVBoxLayout()
        fossilTab.setLayout(fossilTab_layout)
        tab_widget.addTab(fossilTab, 'Fossil Recorder')
        self.connectRobot = QPushButton("Connect and Start sampling. ")
        fossilTab_layout.addWidget(self.connectRobot)
        self.connectRobot.pressed.connect(self.connect2Robot)
        self.tDist = QLineEdit(f"{_Variables.tStep}", self)
        fossilTab_layout.addWidget(self.tDist)
        self.tDist.textChanged.connect(self.fossilStepCheck)

        ## Graphics for well position.
        scene = QGraphicsScene()
        view = QGraphicsView(scene)
        fossilTab_layout.addWidget(view)
        circle_diameter, spacing = 50, 10
        # Draw 24 circles initially in grey
        for i in range(24):
            x = i % 6  # Calculate column (new column every 6 circles)
            y = i // 6  # Calculate row
            position_x = (x * (circle_diameter + spacing))
            position_y = (y * (circle_diameter + spacing))
            # Create and add a grey circle to the scene
            circle = scene.addEllipse(QRectF(position_x, position_y, circle_diameter, circle_diameter), brush=QBrush(QColor('grey')))
            self.circs.append(circle)

        # Setup a timer for live updates
        self.timer = QTimer()
        self.timer.setInterval(100)  # Time in milliseconds
        self.timer.timeout.connect(self.updateGraphs)
        self.timer.start()
        self.thread1 = threading.Thread(target=Tools.dataHandle)

    def closeEvent(self, event):
        '''
        Hopefully crash events are also handled by this lmfao.
        '''
        # integral for the threading comms method (fast as possible communication with device(s))
        print('Ending communication to micro controller... ')
        _Variables.startDHandle = False
        Tools.createFolder() # If folder is present it  points towards folder.
        Tools.dataSave(_Variables.photodiode_1_main, _Variables.photodiode_1_basis, _Variables.photodiode_2_main, _Variables.photodiode_2_basis,
                        _Variables.photodiode_3_main, _Variables.photodiode_3_basis, _Variables.OD1, _Variables.OD2, _Variables.OD3, _Variables.ambientTemp, _Variables.objTemp, _Variables.Coeff_1, _Variables.Coeff_2, _Variables.Coeff_3, _Variables.hardwareTime)
        super().closeEvent(event)

    def startRun(self):
        if self.startState:
            # self.connectStart.setStyleSheet('background-color: red'), 
            self.connectStart.setText("Run in progress... "), self.connectStart.setDisabled(True)
            _Variables.startDHandle = True
            Tools.startSeq()
            if self.initialStart:      self.thread1.start()
    
    def sterlSeq(self, ) -> None:
        sterlThread = threading.Thread(target=Sterl.sterlSeq)
        
        if not _Variables.sterlActive:
            sterlThread.start()
            self.startSterl.setDisabled(True)
            _Variables.sterlActive = True
        else:   pass
    
    def connect2Robot(self, ):
        roboticArm()
    
    def updateGraphs(self, ):
        self.rawReadings.update_plot(idx=1)
        self.opticalDensity.update_plot(idx=2)
        self.temperature.update_plot(idx=3)
    
    def qkSave(self):
        Tools.dataSave(_Variables.photodiode_1_main, _Variables.photodiode_1_basis, _Variables.photodiode_2_main, _Variables.photodiode_2_basis,
                        _Variables.photodiode_3_main, _Variables.photodiode_3_basis, _Variables.ambientTemp, _Variables.objTemp, _Variables.Coeff_1, _Variables.Coeff_2, _Variables.Coeff_3, _Variables.hardwareTime)
    
    def fossilStepCheck(self, ) -> None:
        try:
            text = self.tDist.text()
            _Variables.tStep = float(text)
        except:
            print("Error with fossil time step input. Ensure numbers only.")
            _Variables.tStep = _Variables.tStep


    ## Need to make it a single check function for a given motor... self.X.text() can just be an input variable... the **args can just be _variables.Xdir, _variables.Xspeed...
    def updateCM(self, ):
        try:
            CM = self.cSpeedEdit.text()
            _Variables.cDir, _Variables.cSpeed = Tools.checkMotorValues(CM)
            _Variables.pyMessage[1], _Variables.pyMessage[2] = _Variables.cDir, _Variables.cSpeed
        except:
            _Variables.pyMessage[1], _Variables.pyMessage[2] = _Variables.cDir, _Variables.cSpeed
    
    def stepper1Change(self, ):
        try:
            check = self.m1SpeedEdit.text()
            _Variables.stepper1Dir, _Variables.stepper1Speed = Tools.checkMotorValues(check)
            _Variables.pyMessage[3], _Variables.pyMessage[4] = _Variables.stepper1Dir, _Variables.stepper1Speed
        except:
            _Variables.pyMessage[3], _Variables.pyMessage[4] = _Variables.stepper1Dir, _Variables.stepper1Speed

    def stepper2Change(self, ):
        try:
            check = self.m2SpeedEdit.text()
            _Variables.stepper2Dir, _Variables.stepper2Speed = Tools.checkMotorValues(check)
            _Variables.pyMessage[5], _Variables.pyMessage[6] = _Variables.stepper2Dir, _Variables.stepper2Speed
        except:
            _Variables.pyMessage[5], _Variables.pyMessage[6] = _Variables.stepper2Dir, _Variables.stepper2Speed


    def updateFS(self, ):
        try:
            FS = self.fanSpeedEdit.text()
            _, _Variables.fanSpeed = Tools.checkMotorValues(FS)
            _Variables.pyMessage[7] = _Variables.fanSpeed
        except:
            _Variables.pyMessage[7] = _Variables.fanSpeed
    
    def updateMM(self, ):
        try:
            MM = self.motherMachineSpeed.text()
            _, _Variables.motherMachineSpeed = Tools.checkMotorValues(MM)
            _Variables.pyMessage[19] = _Variables.motherMachineSpeed
        except:
            _Variables.pyMessage[19] = _Variables.motherMachineSpeed
    
    def updateTargTemp(self, ):
        try:
            _Variables.pyMessage[14], _Variables.pyMessage[15], _Variables.pyMessage[16], _Variables.pyMessage[17] = Tools.float2bytes(float(self.targTempEdit.text()))
        except:
            _Variables.pyMessage[14], _Variables.pyMessage[15], _Variables.pyMessage[16], _Variables.pyMessage[17] = Tools.float2bytes(_Variables.targetTemp)
    
    def updateTargOD(self, ):
        try:
            _Variables.pyMessage[10], _Variables.pyMessage[11], _Variables.pyMessage[12], _Variables.pyMessage[13] = Tools.float2bytes(float(self.targODEdit.text()))
        except:
            _Variables.pyMessage[10], _Variables.pyMessage[11], _Variables.pyMessage[12], _Variables.pyMessage[13] = Tools.float2bytes(_Variables.targetOD)
   
    def updateVariables(self, ):
        targOD, targTemp = self.float2bytes(_Variables.targetOD), self.float2bytes(_Variables.targetTemp)
        _Variables.pyMessage[0] = _Variables.deviceStatus
        _Variables.pyMessage[1] = _Variables.cDir
        _Variables.pyMessage[2] = _Variables.cSpeed
        ## Leave 3 to 6 for turbidostat motors - They'll be 0 anyways (and dir).

        _Variables.pyMessage[7] = _Variables.fanSpeed
        ## Leave 8 and 9 for Mother Machine control

        _Variables.pyMessage[10] = targOD[0]
        _Variables.pyMessage[11] = targOD[1]
        _Variables.pyMessage[12] = targOD[2]
        _Variables.pyMessage[13] = targOD[3]

        _Variables.pyMessage[14] = targTemp[0]
        _Variables.pyMessage[15] = targTemp[1]
        _Variables.pyMessage[16] = targTemp[2]
        _Variables.pyMessage[17] = targTemp[3]
    
    def resetData(self, ):
        Tools.clearArrays()


class PlotCanvas(FigureCanvas):
    def __init__(self, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        FigureCanvas.__init__(self, self.fig)
        self.plot()

    def plot(self):
        self.axes.set_title('Raw power graph over time')
        self.axes.set_xlabel('Time (s)')
        self.axes.set_ylabel('Raw power (nw)')
        self.draw()

    def update_plot(self, idx):
        if idx == 1 and len(_Variables.photodiode_3_basis) == len(_Variables.hardwareTime) and len(_Variables.photodiode_3_main) == len(_Variables.hardwareTime):
            try:
                self.axes.clear()
                self.axes.plot(_Variables.hardwareTime, _Variables.photodiode_1_main, 'r-', alpha=0.5)
                self.axes.plot(_Variables.hardwareTime, _Variables.photodiode_2_main, 'g-', alpha=0.5)
                self.axes.plot(_Variables.hardwareTime, _Variables.photodiode_3_main, 'b-', alpha=0.5)
                self.axes.plot(_Variables.hardwareTime, _Variables.photodiode_1_basis, 'r:', alpha=0.5)
                self.axes.plot(_Variables.hardwareTime, _Variables.photodiode_2_basis, 'g:', alpha=0.5)
                self.axes.plot(_Variables.hardwareTime, _Variables.photodiode_3_basis, 'b:', alpha=0.5)
                self.axes.set_title('Raw Power (nW) over Time (s)')
                self.axes.set_xlabel('Time (s)')
                self.axes.set_ylabel('Raw power (nw)')
                self.draw()
            except:     print('plt error')
        else:   pass
        if idx == 2 and len(_Variables.hardwareTime) == len(_Variables.OD2):
            try:
                self.axes.clear()
                self.axes.plot(_Variables.hardwareTime, _Variables.OD2, 'g-', alpha=0.5)
                self.axes.set_title('OD as a function of time')
                self.axes.set_xlabel('Time (s)')
                self.axes.set_ylabel('Optical Density')
                self.draw()
            except:     print('plt error')
        else:   pass
        if idx == 3 and len(_Variables.ambientTemp) == len(_Variables.hardwareTime) and len(_Variables.objTemp) == len(_Variables.hardwareTime):
            self.axes.clear()
            try:
                self.axes.plot(_Variables.hardwareTime, _Variables.ambientTemp, 'r-', alpha=0.5)
                self.axes.plot(_Variables.hardwareTime, _Variables.objTemp, 'g-', alpha=0.5)
                self.axes.set_title('Temperature over time')
                self.axes.set_xlabel('Time (s)')
                self.axes.set_ylabel('Temperature (Celius)')
                self.draw()
            except:     print('plt error')
        else:   pass

class roboticArm:
    wastePosition = [150, 100, 100] # let r (rHead) be 0.0
    startingPosition = [140, 0, 0] # left closest well is the typical starting position...
    xOffset, yOffset = 18.9, 18.9 # in mm (theoretically).
    def __init__(self, ) -> None:
        '''
        Requries the armDeps inside the aPEX Grow folder to work...
        '''
        
        self.robotAPI = robot.load()
        state = robot.ConnectDobot(self.robotAPI, f"COM5", 115200)[0]
        self.connectState = {
        robot.DobotConnect.DobotConnect_NoError:  "DobotConnect_NoError",
        robot.DobotConnect.DobotConnect_NotFound: "DobotConnect_NotFound",
        robot.DobotConnect.DobotConnect_Occupied: "DobotConnect_Occupied"}
        print("Connection status: ", self.connectState[state])
        if (state == robot.DobotConnect.DobotConnect_NoError):
            self.homed = self.armHoming
            _Variables.armActive = True
        if self.homed:
            self.startHandle
    
    @property
    def armHoming(self, ) -> bool:
        complete = False
        robot.SetQueuedCmdClear(self.robotAPI)
        robot.SetHOMEParams(self.robotAPI, x=150, y=0, z=120, r=0)
        robot.SetHOMECmd(self.robotAPI, temp=0)
        complete = True
        return complete
    
    @property
    def startHandle(self, ) -> None:
        arm = threading.Thread(target=self.armHandle)
        arm.start()
    
    @property
    def armComplete(self, ) -> None:
        robot.DisconnectDobot(self.robotAPI)
        _Variables.armActive = False
    
    def goToWaste(self, sleep, valveState, pumpSpeed) -> None:
        '''
        Goes to the correct waste position, before a run to cycle sterl mixture for example...
        '''
        robot.SetPTPCmdEx(self.robotAPI, robot.PTPMode.PTPMOVLXYZMode, x=self.wastePosition[0], y=self.wastePosition[1], z=self.wastePosition[2]+40, rHead=0.0)
        robot.SetPTPCmdEx(self.robotAPI, robot.PTPMode.PTPMOVLXYZMode, x=self.wastePosition[0], y=self.wastePosition[1], z=self.wastePosition[2], rHead=0.0)
        valve, pwm = valveState, pumpSpeed
        time.sleep(sleep)
        robot.SetPTPCmdEx(self.robotAPI, robot.PTPMode.PTPMOVLXYZMode, x=self.wastePosition[0], y=self.wastePosition[1], z=self.wastePosition[2]+40, rHead=0.0)


    def armHandle(self, ) -> None:
        '''
        Regular algorithm for arm movements, requires better homing -> unsure how to complete this at the current moment.
        When the sample is being taken i wanna record the OD over that time frame and record it, so we can later individually check the discrete sample points OD reading via this device... +- 100 seconds for example.
        Need to add pinch valve _Variables.PyMessage + one for the pump required. ~ 3 pinch valves? Three single (Double for EtOH ~ 20% and dH2O) and the single for the main chamber.
        Pinch valves thus only need 4 states -> [0, 0, 1]: [0, 1, 0]: [1, 0, 0]: [0, 0, 0]. Water state, EtOH state, sampling state, hover state. Thus sending a single pyMessage is possible -> 0 to 3.
        '''
        column, row = 0, 0
        i = 0
        while _Variables.armActive:
            if row > 3:
                self.armComplete
                break
            self.goToWaste(sleep=_Variables.pumpTime, valveState=_Variables.valveState[0], pumpSpeed=255)
            robot.SetPTPCmdEx(self.robotAPI, robot.PTPMode.PTPMOVLXYZMode, x=self.startingPosition[0]+(column*self.xOffset), y=self.startingPosition[1]+(row*self.yOffset), z=self.startingPosition[2]+20, rHead=0.0) ## z Position changes, careful for it...
            robot.SetPTPCmdEx(self.robotAPI, robot.PTPMode.PTPMOVLXYZMode, x=self.startingPosition[0]+(column*self.xOffset), y=self.startingPosition[1]+(row*self.yOffset), z=self.startingPosition[2], rHead=0.0) ## z Position changes, careful for it...
            vavle, pwm = _Variables.valveState[1], 255
            time.sleep(_Variables.pumpTime) # Now I want the sample to come out getting enough of the sample to be measurable via the OD600/CFU.
            self.goToWaste(sleep=_Variables.pumpTime, valveState=_Variables.valveState[1], pumpSpeed=-255)
            valve, pwm = _Variables.valveState[2], 255 # This is only for one strel solu.
            time.sleep(_Variables.pumpTime)
            # Now a run is complete and we have the discrete step timer... -> 100 seconds per step, therefore time.sleep(100) -> step per sample. however factor in, 80 seconds of sleeping and 20 seconds of arm movement, thus -> time.sleep(0)
            # So we can do something like, ~ t(step) = t(point) - 100 seconds, where t(step) is the true sample step. Thus the minimum time for this example would be time.sleep(1)...
            time.sleep(_Variables.tStep)
            column += 1
            if column > 5:
                column = 0
                row += 1
            # Visual depiction of the wells that are currently complete within a given run.
            if i < len(App.circs):
                App.circs[i].setBrush(QBrush(QColor("Green")))
                i += 1

class Sterl:
    introTime, cycleTime = 40, 1500 # Seconds.
    seqDone = None
    def __init__(self, ) -> None:
        pass
    
    def sterlSeq(self, ):
        def motorSeq(startTime, motorPos) -> None:
            while not self.seqDone:
                os.system('cls')    
                print(abs(time.time() - startTime), "Time (s)")
                print(_Variables.pyMessage[19], motorPos+10)

                if abs(time.time()- startTime) < self.introTime:
                    # This takes out any media from either the start of sterlisation or prior liquid.
                    _Variables.pyMessage[19] = 14
                if abs(time.time() - startTime) > self.introTime and abs(time.time() - startTime) < (self.introTime + self.introTime):
                    # This stops the waste motor and starts the first motor (for bleach introduction).
                    _Variables.pyMessage[19] = (motorPos+10)
                if abs(time.time() - startTime) > (self.introTime + self.introTime) and abs(time.time() - startTime) < (self.cycleTime + self.introTime):
                    # Now we start cycling the liquid throughout the system for X seconds.
                    _Variables.pyMessage[19] = 19 # 19 kills all the motors, setting them to 0 PWM output.
                    ''' I should make the cycle Motor set to 255 in the 19 status code. Might need to change this part now ... '''
                if abs(time.time() - startTime) > (self.introTime + self.cycleTime):
                    # Now were done with that liquid lets move through the for loop to the next motor.
                    # Thus, ends the sequence.
                    self.seqDone = True
                    print(_Variables.pyMessage[19], motorPos+10)

        for i in range(1, 4):
            self.seqDone = False
            motorSeq(startTime=time.time(), motorPos=i)
        _Variables.pyMessage[19] = 255 # Signals that the sterlisation is now complete.

if __name__ == '__main__':
    if _Variables.armPresent:
        # this is for the fossil record not required for the stand alone system.
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        os.chdir(f"{os.getcwd()}\\armDep")
        import armDep.DobotDllType as robot
        #robotAPI = robot.load()
    app = QApplication(sys.argv)
    ex = App()
    ex.show()
    sys.exit(app.exec())